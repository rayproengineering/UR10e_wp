#!/usr/bin/env python3

import pyvista as pv
import  numpy as np
import networkx as nx
from networkx.algorithms import approximation
import scipy
from scipy.interpolate import make_smoothing_spline
from copy import deepcopy
import copy

import rospy
from trac_ik_python.trac_ik import IK
import moveit_commander
import geometry_msgs.msg as geometry_msgs
import sys
import moveit_msgs.msg
import shape_msgs
from std_msgs.msg import String
from moveit_commander.conversions import pose_to_list
import moveit.core.collision_detection

import trajectory_msgs.msg
import std_msgs.msg

import matplotlib as mpl
import matplotlib.pyplot as plt
from moveit_msgs.msg import RobotTrajectory
import actionlib
import actionlib_msgs

import Weld_Select
from Weld_Select import Create_Welds
from Weld_Select import *
import LKH_solver
from LKH_solver import *
import vlc
# import MIP_solver
# from MIP_solver import *
# from MIP_solver import MIP_solver_edge_constraints




JOINT_NAMES = [
    "shoulder_pan_joint",
    "shoulder_lift_joint",
    "elbow_joint",
    "wrist_1_joint",
    "wrist_2_joint",
    "wrist_3_joint",
]



def euclidean_linspace(start,stop,steps):
    x=np.linspace(start[0],stop[0],steps)
    y=np.linspace(start[1],stop[1],steps)
    z=np.linspace(start[2],stop[2],steps)
    points=[]
    for n in range(len(x)):
        points.append(tuple([x[n],y[n],z[n]]))
    return points

def euclidean_logspace(start,stop,steps):
    x=np.logspace(start[0],stop[0],steps)
    y=np.logspace(start[1],stop[1],steps)
    z=np.linspace(start[2],stop[2],steps)
    points=[]
    for n in range(len(x)):
        points.append(tuple([x[n],y[n],z[n]]))
    return points

def angle_linespace(start,stop,steps):
    angle1=np.arctan2(start[1],start[0])
    angle2=np.arctan2(stop[1],stop[0])

    if angle1<0:
        angle1=(2*np.pi)+angle1

    if angle2<0:
        angle2=(2*np.pi)+angle2

    delta_angle=angle2-angle1

    if angle1%(np.pi/2)==0:
        print(angle1)
    if angle2%(np.pi/2)==0:
        print(angle2)

    if abs(delta_angle)>np.pi:
        delta_angle=(2*np.pi-abs(delta_angle))*-1*np.sign(delta_angle)

    angle_step=delta_angle/steps
    return_angles=[]
    return_vectors=[]

    for n in range(steps):
        next_angle=angle1+n*angle_step
        return_angles.append(next_angle)
        return_vectors.append((np.cos(next_angle),np.sin(next_angle),0))
    
    return return_vectors,return_angles

class Weld_bead_test:

    def __init__(self):
        # p1=[0.35415794752355517,0.8013282640586253,-0.19856212526954065]
        # o1=[-0.8358804976934971,0.5489067740704975,-0.0020852078788445158,0.0008937915268301562]

        # p2=[0.3336544359992759,0.8640239870568683,-0.19850255992561744]
        # o2=[-0.835794928571758,0.5490365960507659,-0.0021462073390184798,0.001023408411213564]

        # p3=[0.38303006929974404,0.8476299179717424,-0.04412092553468677]
        # o3=[-0.8354540640463384,0.5495528031710067,-0.0026719996965603988,0.0010410633829261932]

        # p4=[0.30010907141832227,0.8232192594729094,-0.04411393055866114]
        # o4=[0.6310887832723437,0.7757055443481314,0.0014946737312687634,0.002371085371489403]

        # p5=[0.34039955463678184,0.7985768399121906,-0.19873592162834958]
        # o5=[0.5888436375089361,0.8082438076902722,0.0010251993512683762,0.0020166461923623717]

        # p6=[0.3195562579848401,0.863858380786029,-0.1986989469000907]
        # o6=[0.5889558352961545,0.8081617693073206,0.001138373474241032,0.002069494262639881]

        velocity=1
        self.IK_SOLVER=Inverse_Kinematics_Solver()
        self.configuration=self.configuration_type(angles=self.IK_SOLVER.move_group.get_current_joint_values())
        self.lock_geometric_type()
        self.IK_SOLVER.listen_for_points()
        
    def configuration_type(self,angles):
        if type(angles)==type(None):
            print(angles)
            return 3
        else:
            if 0<angles[3]<np.pi or -np.pi>angles[3]>-2*np.pi:
                #configuration short
                return 0
            
            elif np.pi<angles[3]<2*np.pi or 0>angles[3]>-np.pi:
                #configuration long
                return 1
            
            else:
                #configuration indeterminante
                return 2

    def lock_geometric_type(self):
        
        def rotational_bounds(angle):
            quad=angle/np.pi
            b1=np.ceil(quad)*np.pi
            b2=np.floor(quad)*np.pi
            bounds=np.array([b1,b2])
            bounds=np.sort(bounds)
            return bounds
        def lock_wrist_one(joints):
            bounds=rotational_bounds(joints[3])
            if self.configuration_type(joints)==self.configuration:
                #Lock this current configuration
                upper_bounds[3]=bounds[1]
                lower_bounds[3]=bounds[0]
            else:
                #Lock 180 from the current configuration
                if bounds[0]>=0:
                    bounds[0]=bounds[0]-np.pi
                    bounds[1]=bounds[1]-np.pi
                else:
                    bounds[0]=bounds[0]+np.pi
                    bounds[1]=bounds[1]+np.pi
                upper_bounds[3]=bounds[1]
                lower_bounds[3]=bounds[0]
        
        joints=self.IK_SOLVER.move_group.get_current_joint_values()
        lower_bounds=[-2*np.pi]*6
        upper_bounds=[2*np.pi]*6
        lower_bounds[1]=-np.pi
        upper_bounds[1]=0

        shoulder_lift_joint_constraint=moveit_msgs.msg.JointConstraint()
        shoulder_lift_joint_constraint.joint_name=JOINT_NAMES[1]
        shoulder_lift_joint_constraint.position=-np.pi/2
        shoulder_lift_joint_constraint.tolerance_above=np.pi/2
        shoulder_lift_joint_constraint.tolerance_below=np.pi/2
        shoulder_lift_joint_constraint.weight=1.0
        
        elbow_joint_constraint=moveit_msgs.msg.JointConstraint()
        elbow_joint_constraint.joint_name=JOINT_NAMES[2]


        if joints[2]>0:
            print('positive elbow joint')

            elbow_joint_constraint.position=np.pi/2
            elbow_joint_constraint.tolerance_above=np.pi/2
            elbow_joint_constraint.tolerance_below=np.pi/2
            elbow_joint_constraint.weight=1.0
            lower_bounds[2]=elbow_joint_constraint.position-elbow_joint_constraint.tolerance_below
            upper_bounds[2]=elbow_joint_constraint.position+elbow_joint_constraint.tolerance_above
            lock_wrist_one(joints)

        elif joints[2]<0:
            print('negative ebow joint')

            elbow_joint_constraint.position=-np.pi/2
            elbow_joint_constraint.tolerance_above=np.pi/2
            elbow_joint_constraint.tolerance_below=np.pi/2
            elbow_joint_constraint.weight=1.0
            lower_bounds[2]=elbow_joint_constraint.position-elbow_joint_constraint.tolerance_below
            upper_bounds[2]=elbow_joint_constraint.position+elbow_joint_constraint.tolerance_above
            lock_wrist_one(joints)

        else:
            print('indeterminante elbow joint Roman has not programmed this')

        wrist_1_constraint=moveit_msgs.msg.JointConstraint()
        wrist_1_constraint.joint_name=JOINT_NAMES[3]
        self.wrist_1_average=np.average([lower_bounds[3],upper_bounds[3]])
        wrist_1_constraint.position=np.average([lower_bounds[3],upper_bounds[3]])
        wrist_1_constraint.tolerance_above=np.pi
        wrist_1_constraint.tolerance_below=np.pi
        wrist_1_constraint.weight=1.0

        constraints=self.IK_SOLVER.move_group.get_path_constraints()
        constraints.joint_constraints=[shoulder_lift_joint_constraint,elbow_joint_constraint,wrist_1_constraint]
        self.IK_SOLVER.move_group.set_path_constraints(constraints)
        self.IK_SOLVER.IK_SOLVER.set_joint_limits(lower_bounds, upper_bounds)
        self.upper_bounds=upper_bounds
        self.lower_bounds=lower_bounds
        print(constraints)
        print(self.IK_SOLVER.move_group.get_current_joint_values())
    
class Inverse_Kinematics_Solver:
    def __init__(self):
        moveit_commander.roscpp_initialize(sys.argv)
        rospy.init_node('move_group_node',
                anonymous=False)
        self.robot = moveit_commander.RobotCommander()
        self.scene = moveit_commander.PlanningSceneInterface()
        self.aligned_tool0_vector=np.array([0,1,0])
        
        group_name = "manipulator"
        move_group=moveit_commander.MoveGroupCommander(group_name)
        self.move_group = move_group
        self.IK_SOLVER = IK("base",
                "tool0",solve_type="Speed")
        self.weld_speed_scale=0.01*0.6
        self.working_sound = vlc.MediaPlayer("working.mp3")
        self.working_sound.audio_set_volume(200)
        self.tacking_sound = vlc.MediaPlayer('tacking.mp3')
        self.tacking_sound.audio_set_volume(150)
        self.tac_time=1.5
        self.weld_on=True
        self.pub=rospy.Publisher('/enablef',std_msgs.msg.Empty,queue_size=10)
    def get_rotation_from_vectors(self,v1,v2):
        # print(v1)
        # print(v2)
        k=np.cross(v1,v2)
        k=k/np.linalg.norm(k)
        # print(k)
        theta=np.arccos(np.dot(v1,v2)/(np.linalg.norm(v1)*np.linalg.norm(v2)))
        r=scipy.spatial.transform.Rotation.from_rotvec((theta*np.array(k)))
        p=scipy.spatial.transform.Rotation.from_rotvec((np.pi*np.array([0,1,0])))
        # print(r.as_quat())
        # print(p.as_quat())
        r=r*p
        return r
    
    def get_IK(self,point,orientation_vector,seed_state=None):
        # print('Hai')
        # print(orientation_vector)
        if seed_state==None:
            seed_state=self.move_group.get_current_joint_values()
        x=point[0]/100+0.25
        y=point[1]/100+0.30
        z=point[2]/100
        r=self.get_rotation_from_vectors(self.aligned_tool0_vector,orientation_vector)
        quat=r.as_quat()

        sol = (self.IK_SOLVER.get_ik(seed_state,
                                x, y, z,
                                quat[0], quat[1], quat[2], quat[3])
                                )
        
        if not(sol==None):
            angles=list(sol)
        else:
            angles=None

        return angles
    
    def go_and_weld_along(self,p,o):
        waypoints = []
        wpose = self.move_group.get_current_pose().pose
        wpose.position.x=p[0]
        wpose.position.y=p[1]
        wpose.position.z=p[2]
        
        wpose.orientation.x=o[0]
        wpose.orientation.y=o[1]
        wpose.orientation.z=o[2]
        wpose.orientation.w=o[3]
        
        waypoints.append(copy.deepcopy(wpose))

        self.move_group.limit_max_cartesian_link_speed(self.weld_speed_scale,link_name='wrist_3_link')

        (plan, fraction) = self.move_group.compute_cartesian_path(
            waypoints, 0.005, 0.0  # waypoints to follow  # eef_step
        )  # jump_threshold
        
        if self.weld_on==True:
            self.pub.publish()
        
        self.working_sound.play()
        rospy.sleep(0.5)

        self.move_group.execute(plan, wait=True)
        if self.weld_on==True:
            self.pub.publish()
        self.move_group.limit_max_cartesian_link_speed(1,link_name='wrist_3_link')
        self.working_sound.stop()
    
    def go_and_tac(self,p,o):
        waypoints = []
        wpose = self.move_group.get_current_pose().pose
        wpose.position.x=p[0]
        wpose.position.y=p[1]
        wpose.position.z=p[2]
        
        wpose.orientation.x=o[0]
        wpose.orientation.y=o[1]
        wpose.orientation.z=o[2]
        wpose.orientation.w=o[3]
        
        waypoints.append(copy.deepcopy(wpose))
        (plan, fraction) = self.move_group.compute_cartesian_path(
            waypoints, 0.005, 0.0  # waypoints to follow  # eef_step
        )  # jump_threshold
        
        self.move_group.execute(plan, wait=True)
        self.tacking_sound.play()
        rospy.sleep(0.5)
        if self.weld_on==True:
            self.pub.publish()
            rospy.sleep(self.tac_time)
            self.pub.publish()
        self.tacking_sound.stop()

    def just_tac(self):
            self.tacking_sound.play()
            if self.weld_on==True:
                self.pub.publish()
                rospy.sleep(self.tac_time)
                self.pub.publish()
            self.tacking_sound.stop()
            rospy.sleep(self.tac_time)
    def just_go(self,p,o):
        waypoints = []
        wpose = self.move_group.get_current_pose().pose
        wpose.position.x=p[0]
        wpose.position.y=p[1]
        wpose.position.z=p[2]
        
        wpose.orientation.x=o[0]
        wpose.orientation.y=o[1]
        wpose.orientation.z=o[2]
        wpose.orientation.w=o[3]
        
        waypoints.append(copy.deepcopy(wpose))
        (plan, fraction) = self.move_group.compute_cartesian_path(
            waypoints, 0.005, 0.0  # waypoints to follow  # eef_step
        )  # jump_threshold
        
        self.move_group.execute(plan, wait=True)

    def callback(self,data):
        print('Here is the list of points:')
        print(data.poses[:])
        
        pose_list=data.poses[:]
        print('There are,'+str(int(len(pose_list)))+' Points')
        point_command_list=[]
        saved_path_query= input("Enter the file name if you have a saved path, otherwise press enter to create one from the desired points:")
        if (saved_path_query==''):
            b=1
            while b==1:
                get_point = input("Enter the point number for the desired command, Enter e to exit and es to exit and save:")
                if get_point=='e':
                    b=0
                    break
                elif get_point=='es':
                    file_name=input('Enter the File name for the saved path:')
                    np.save(file_name,point_command_list)
                    np.save(file=('point_data'+'_'+file_name),arr=pose_list)

                get_command = input("Enter the desired command type (t- go to point and tack,w- go to point and weld along the way,g- go to point,jt-just tac):")
                try:
                    if b==1:
                        point_command_list.append([int(get_point),str(get_command)])
                        print(point_command_list)
                except:
                    print('Error in taking point try again')
        else:
            pass


        for n in range(len(point_command_list)):
            pose=pose_list[point_command_list[n][0]]
            p=[pose.position.x,pose.position.y,pose.position.z]
            o=[pose.orientation.x,pose.orientation.y,pose.orientation.z,pose.orientation.w]
            if point_command_list[n][1]=='t':
                self.go_and_tac(p,o)
            elif point_command_list[n][1]=='w':
                self.go_and_weld_along(p,o)
            elif point_command_list[n][1]=='g':
                self.just_go(p,o)
            elif point_command_list[n][1]=='jt':
                self.just_tac()

    def listen_for_points(self):
        #write code to get points here
        while not rospy.is_shutdown():
            rospy.Subscriber('desired_points', geometry_msgs.PoseArray, self.callback)
        
if __name__ == "__main__":
    #write code to get points here
    Weld_bead_test()
