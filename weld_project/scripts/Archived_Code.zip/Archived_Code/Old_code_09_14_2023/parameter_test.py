#!/usr/bin/env python


import scipy
import numpy as np
import grid_class_v1
from grid_class_v1 import TSP_solution
from grid_class_v1 import *
import Create_Weld_Mesh
from Create_Weld_Mesh import *
from Create_Weld_Mesh import Weld_Mesh

import Weld_Select
from Weld_Select import Create_Welds
from Weld_Select import *
import pyvista as pv

if __name__ == "__main__":

    IK_SOLVER=Inverse_Kinematics_Solver(weld_on=True,sound_on=False)
    matched_points=[]
    matched_orientations=[]
    plotter=pv.Plotter()

    for n in range(0,2):
        get = input("Press Enter to Take a Point:")
        # print(n)
        # point=IK_SOLVER.return_read_point(point=n,fake_cord=fake_pose_cord,fake_rotation=rotation,noise_scale=None)
        point,orientation=IK_SOLVER.return_read_point(return_rotation=True)
        print('Read Point:')
        print(point)
        matched_points.append(deepcopy(point))
        matched_orientations.append(deepcopy(orientation))
        print(matched_points)

    # matched_points=np.array(matched_points)
    # np.save('matched_paramater_points',matched_points)
    # np.save('matched_paramater_orientations',matched_orientations)
    
    # exit()

    matched_points=np.load('matched_paramater_points.npy')
    matched_orientations=np.load('matched_paramater_orientations.npy')
    
    
    # matched_points[:,2]=np.average(matched_points[:,2])

    p2=matched_points[0]
    p1=matched_points[1]
    # p2[-1]=0
    # p1[-1]=0
    
    pdist=np.linalg.norm(np.array(p2)-np.array(p1))
    weld_length=6*0.0254
    number_of_lines=np.floor(pdist/(weld_length))

    directional_vector=(np.array(p2)-np.array(p1))/pdist
    weld_lines=[]
    
    for n in range(0,int(number_of_lines)):
        weld_lines.append([p1+n*weld_length*directional_vector,p1+(n+1)*weld_length*directional_vector])

    Weld_Operator=TSP_solution(IK_SOLVER=IK_SOLVER)

    R1=scipy.spatial.transform.Rotation.from_quat(matched_orientations[0])
    R2=scipy.spatial.transform.Rotation.from_quat(matched_orientations[-1])
    print(R1)
    print(R2)
    y_orientation=(R1.as_matrix()[1,0:3]+R2.as_matrix()[1,0:3])/2
    general_normal=np.cross(directional_vector,[0,0,1])
    general_normal=general_normal*-1*np.sign(np.dot(general_normal,y_orientation))
    normal_1=general_normal+directional_vector
    normal_1=normal_1/np.linalg.norm(normal_1)
    normal_2=general_normal+-directional_vector
    normal_2=normal_2/np.linalg.norm(normal_2)
    normal_1[-1]=1
    normal_2[-1]=1
    print(normal_1)
    print(normal_2)
    # normal_1=normal_1/np.linalg.norm(normal_1)
    # normal_2=normal_2/np.linalg.norm(normal_2)
    
    control_distance=Weld_Operator.control_distance
    print(control_distance)
    
    Weld_Operator.normals_closest=normal_1
    Weld_Operator.configuration=Weld_Operator.configuration_type(Weld_Operator.IK_SOLVER.move_group.get_current_joint_values())
    Weld_Operator.lock_geometric_type()
    Weld_Operator.tacking=False
    middle_normal=deepcopy(general_normal)/np.linalg.norm(general_normal)
    middle_normal[-1]=1
    middle_normal=middle_normal/np.linalg.norm(middle_normal)
    # middle_normal=np.array([0,0,1])
    blue = np.array([12 / 256, 238 / 256, 246 / 256, 1.0])
    black = np.array([11 / 256, 11 / 256, 11 / 256, 1.0])
    grey = np.array([189 / 256, 189 / 256, 189 / 256, 1.0])
    yellow = np.array([255 / 256, 247 / 256, 0 / 256, 1.0])
    red = np.array([1.0, 0.0, 0.0, 1.0])

    # IK_SOLVER.just_tack()
    # exit()
    # print(len(weld_lines))
    for n in range(3,len(weld_lines)):
        wp1=weld_lines[n][0]
        wp2=weld_lines[n][1]
        Weld_Operator.closest_point=wp1
        
        # point_1=tuple(np.array(wp1)+(np.array(normal_1)/np.linalg.norm(normal_1))*control_distance)
        # point_3=tuple(np.array(wp2)+(np.array(normal_2)/np.linalg.norm(normal_2))*control_distance)
        # point_2=tuple(((wp1+wp2)/2)+middle_normal*control_distance)
        
        
        # point_2=tuple(((np.array(point_1)+np.array(point_3))/2)-(0.41421356237)*middle_normal*control_distance)
        # point_2=tuple(((np.array(point_1)+np.array(point_3))/2))
        # point_2=tuple(((wp1+wp2)/2))
        print(len(weld_lines))
        if IK_SOLVER.weld_on==True:
            while True:
                get_wire_speed=input('Select the feed rate for the welder, e to exit:')
                if get_wire_speed=='e':
                    break
                IK_SOLVER.wire_set.publish(int(get_wire_speed))
                # else:
                #     try:
                #         IK_SOLVER.wire_set(int(get_wire_speed))
                #     except:
                #         print('Please Enter a valid number')
            while True:
                get_weld_voltage=input('Select the voltage for the welder, e to exit:')
                if get_weld_voltage=='e':
                    break
                else:
                    try:
                        IK_SOLVER.weld_set.publish(int(get_weld_voltage))
                    except:
                        print('Please Enter a valid number')
            print('The current weld velocity is: '+str(IK_SOLVER.weld_velocity))
            change_welding_speed=input('Would you like to change the welding speed, type y/n: ')
            if change_welding_speed=='y':
                while True:
                    get_weld_speed=input('Select the velocity for the weld arm, e to exit:')
                    if get_weld_speed=='e':
                        break
                    else:
                        try:
                            IK_SOLVER.weld_velocity=float(get_weld_speed)
                        except:
                            print('Please Enter a valid number')
        


        


        # control_points=np.array(euclidean_linspace(point_1,point_2,5)+euclidean_linspace(point_2,point_3,5)[1:])
        control_points=np.array(euclidean_linspace(wp1,wp2,20))
        # control_points=np.array(euclidean_linspace(point_1,point_2,5))
        # edge=edge_line(control_points,deepcopy(normal_1),deepcopy(normal_2))
        edge=weld_edge_double_corner_turn(control_points=control_points,normal1=normal_1,normal2=normal_2,control_distance=0.015)
        # edge=edge_line(control_points,deepcopy(normal_1),deepcopy(middle_normal))
        edge.make_smooth_line(Smoothness_Coefficient=30,Interpolation_Resolution=10000,Weight_Ratio=None)
        edge.compute_joint_distances(IK_SOLVER,seed_state=list(IK_SOLVER.move_group.get_current_joint_values()))
        edge.make_orientation_vectors()

        
        
        # lines= pv.lines_from_points(edge.Path)
        # plotter.add_mesh(lines,line_width=5,color=black)
        # plotter.show()
        

        Weld_Operator.edge_object_list=[edge]
        Weld_Operator.correct_first_point()

        # IK_SOLVER.move_group.go(edge.angles[0],wait=True)
        # edge.angles[0]=IK_SOLVER.move_group.get_current_joint_values()
        # print('current joint angles')
        # print(IK_SOLVER.move_group.get_current_joint_values())
        # input('send to the robot?')

        # Weld_Operator.tacking=True
        
        Weld_Operator.Send_to_robot()
        input('weld next edge?:')


        