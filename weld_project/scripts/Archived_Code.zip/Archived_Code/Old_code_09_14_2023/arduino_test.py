#!/usr/bin/env python3
from pickletools import uint8
import queue
import sys
import copy
import rospy
import tf2_ros
import tf
import moveit_commander
import moveit_msgs.msg
import geometry_msgs.msg
#from math import pi
import math
import std_msgs.msg
from std_msgs.msg import String
from moveit_commander.conversions import pose_to_list
from ur_msgs.msg import IOStates
from ur_msgs.msg import Digital
import ur_msgs
from ur_msgs.srv import SetIO

rospy.init_node('led_pub')
pub = rospy.Publisher('/enablef',std_msgs.msg.Empty,queue_size=10)
pub.publish()
rospy.sleep(5)
pub.publish()
    