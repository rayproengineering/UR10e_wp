#!/usr/bin/env python3

import pyvista as pv
import numpy as np
import scipy
from copy import deepcopy
import copy
from copy import deepcopy
import math

def make_uneven_array(interval,long,short):
    corn=[0]
    for n in range(int(interval)):
        if ((n+1)%2)==0:
            corn.append(corn[n]+short)
        else:
            corn.append(corn[n]+long)
    print(corn)
    return np.array(corn)

class Weld_Mesh:
    def __init__(self,longx,shortx,x_interval,longy,shorty,y_interval,z_interval,plate_height,slotheight):
        ni, nj, nk = int(x_interval), int(y_interval), int(z_interval)
        sk = plate_height
        self.plate_height=plate_height
        self.slotheight=slotheight
        self.shortx=shortx
        self.shorty=shorty
        self.longx=longx
        self.longy=longy


        xcorn1=make_uneven_array(ni,longx,shortx)
        xcorn = np.repeat(xcorn1, 2)
        xcorn = xcorn[1:-1]
        xcorn = np.tile(xcorn, 4 * nj * nk)

        ycorn1=make_uneven_array(nj,longy,shorty)
        ycorn = np.repeat(ycorn1, 2)
        ycorn = ycorn[1:-1]
        ycorn = np.tile(ycorn, (2 * ni, 2 * nk))
        ycorn = np.transpose(ycorn)
        ycorn = ycorn.flatten()

        zcorn1 = np.arange(0, (nk + 1) * sk, sk)
        zcorn = np.repeat(zcorn1, 2)
        zcorn = zcorn[1:-1]
        zcorn = np.repeat(zcorn, (4 * ni * nj))

        corners = np.stack((xcorn, ycorn, zcorn))
        corners = corners.transpose()
        
        boxes=[]

        for n in range(int((len(xcorn1)-2)/2)):
            dim1=(xcorn1[(n*2)+1], xcorn1[(n*2)+2], ycorn[0], ycorn[-1], zcorn1[0], zcorn1[-1]+slotheight)
            box1=pv.Box(bounds=dim1)
            boxes.append(box1)

        for n in range(int((len(ycorn1)-2)/2)):
            dim1=(xcorn1[0], xcorn1[-1], ycorn1[(n*2)+1], ycorn1[(n*2)+2], zcorn1[0], zcorn1[-1]+slotheight)
            box1=pv.Box(bounds=dim1)
            boxes.append(box1)
        
        if pv._vtk.VTK9:
            dims = np.asarray((ni, nj, nk)) + 1
            grid = pv.ExplicitStructuredGrid(dims, corners)
            grid = grid.compute_connectivity()
            boxes.append(grid)
 
        block = pv.MultiBlock(boxes)
        self.weld_unstruct_grid= block.combine(merge_points=True)
        self.weld_mesh_geo=self.weld_unstruct_grid.extract_geometry()
        # self.weld_unstruct_grid.save('Weld_Mesh_V1.vtk')
        self.weld_mesh_geo.plot()
        desired_points=[]
        bounds=self.weld_unstruct_grid.bounds
        points=self.weld_mesh_geo.points

        for n in range(len(self.weld_unstruct_grid.points)):
            point=points[n]

            if not(point[0]==bounds[0]) and not(point[0]==bounds[1]) and not(point[1]==bounds[2]) and not(point[1]==bounds[3]) \
                and not(point[2]==bounds[4]) and not(point[2]==bounds[5]):
                desired_points.append(tuple(point))
        self.desired_points=desired_points





class Weld_Mesh_Sangam:
    def __init__(self,long1,long2,short,plate_height,slotheight):
        corn=[0,long1,short,long2,short,long2,short,long1]
        boxes=[]
        
        # corn=[long1,short,long2,short,long2,short,long1]
        print(corn)
        for n in range(len(corn)-1):
            # print('hai 1')
            x1=np.sum(corn[0:n+1])
            x2=np.sum(corn[0:n+2])
            for k in range(len(corn)-1):
                y1=np.sum(corn[0:k+1])
                y2=np.sum(corn[0:k+2])
                if math.isclose(abs(x2-x1),abs(corn[2]),abs_tol=10**-3) or math.isclose(abs(y2-y1),abs(corn[2]),abs_tol=10**-3):
                    # print('hai')
                    dim=(x1,x2,y1,y2,plate_height,plate_height+slotheight)
                    # print(dim)
                    box=pv.Box(bounds=dim)
                    box.compute_normals()
                    boxes.append(deepcopy(box))

        
        dim=(0,np.sum(corn),0,np.sum(corn),0,plate_height)
        box=pv.Box(bounds=dim)
        boxes.append(box)
        block = pv.MultiBlock(boxes)
        # block.plot()
        # block._compute_normals()
        self.weld_unstruct_grid=block
        self.weld_unstruct_grid= block.combine(merge_points=False)
        self.weld_mesh_geo=self.weld_unstruct_grid.extract_geometry()
        
        data=self.weld_mesh_geo.compute_normals(auto_orient_normals=True,consistent_normals=True,split_vertices=False,inplace=False)
        print(data)
        # data.plot()
        # cell_normals=True,
        # point_normals=True,
        # split_vertices=False,
        # flip_normals=False,
        # consistent_normals=True,
        # auto_orient_normals=False,
        # non_manifold_traversal=True,
        # feature_angle=30.0,
        # track_vertices=False,
        # progress_bar=False,

        # self.weld_mesh_geo=block.extract_geometry()
        # self.weld_unstruct_grid.save('Weld_Mesh_sangam_roman_edit.vtk')
        # self.weld_unstruct_grid.save('Weld_Mesh_sangam_roman_edit.stl')
        # self.weld_mesh_geo.show()
        desired_points=[]
        bounds=self.weld_unstruct_grid.bounds
        points=self.weld_mesh_geo.points
        data.plot_normals(mag=0.1,opacity=0.9)
        # print(data2)
        data.save('Weld_Mesh_sangam_roman_edit_v3.vtk')

        for n in range(len(self.weld_unstruct_grid.points)):
            point=points[n]

            if not(point[0]==bounds[0]) and not(point[0]==bounds[1]) and not(point[1]==bounds[2]) and not(point[1]==bounds[3]) \
                and not(point[2]==bounds[4]) and not(point[2]==bounds[5]):
                desired_points.append(tuple(point))
        self.desired_points=desired_points







