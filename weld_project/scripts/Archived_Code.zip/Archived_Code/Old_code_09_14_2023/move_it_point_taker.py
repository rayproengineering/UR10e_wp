#!/usr/bin/env python
import rospy
import sys
import tf2_ros
import geometry_msgs.msg as geometry_msgs
import numpy as np
import sys
import copy
import rospy
import moveit_commander
import moveit_msgs.msg
from moveit_msgs.msg import RobotState
import geometry_msgs.msg as geometry_msgs
from math import pi
from std_msgs.msg import String
from moveit_commander.conversions import pose_to_list

def get_points():
        moveit_commander.roscpp_initialize(sys.argv)
        rospy.init_node('take_points', anonymous=True)

        robot = moveit_commander.RobotCommander()
        group_name = "manipulator"
        move_group = moveit_commander.MoveGroupCommander(group_name)
        rate = rospy.Rate(10)
        points = []
        v = 0
        pub= rospy.Publisher('desired_points', geometry_msgs.PoseArray ,queue_size=10)
        msg= geometry_msgs.PoseArray()
        b=1
        while not rospy.is_shutdown() and b==1:
            get = input("Press Enter to Take a Point,Type e to exit:")
            if get == "":
                try:
                    point=move_group.get_current_pose().pose
                    points.append(point)
                    print(point)
                except rospy.ROSInterruptException:
                    pass
            elif get == 'e':
                b=0
                break
            rate.sleep()

        msg.poses=points
        rospy.sleep(10)
        
        
        
        
        while not rospy.is_shutdown():
            pub.publish(msg)
            rate.sleep()
            # rospy.loginfo_once(msg)
        
def extract_pose_data(Pose,datatype):
    data=[]
    data.append((Pose.position.x, Pose.position.y, Pose.position.z\
        ,Pose.orientation.x, Pose.orientation.y, Pose.orientation.z, Pose.orientation.w))
    return(data)

if __name__ == "__main__":
    get_points()