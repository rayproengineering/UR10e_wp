import scipy
import numpy as np
import grid_class_v1
from grid_class_v1 import TSP_solution
from grid_class_v1 import *
import Create_Weld_Mesh
from Create_Weld_Mesh import *
from Create_Weld_Mesh import Weld_Mesh

import Weld_Select
from Weld_Select import Create_Welds
from Weld_Select import *
import pyvista as pv


if __name__ == "__main__":
    blue = np.array([12 / 256, 238 / 256, 246 / 256, 1.0])
    black = np.array([11 / 256, 11 / 256, 11 / 256, 1.0])
    grey = np.array([189 / 256, 189 / 256, 189 / 256, 1.0])
    yellow = np.array([255 / 256, 247 / 256, 0 / 256, 1.0])
    red = np.array([1.0, 0.0, 0.0, 1.0])
    
    def query(P1):
        print(P1)

        cells=Weld_Mesh.find_cells_along_line(P1,P1)
        print(cells)
        
        # cell_point=Weld_Mesh.find_containing_cell(P1)
        # print(cell_point)
        # print(Weld_Mesh.cell_normals[cell_point])
        # cell_closest=Weld_Mesh.find_closest_cell(P1)
        # print(cell_closest)
        # point=Weld_Mesh.find_closest_point(P1)
        # print(point)
        # print(Weld_Mesh.point_normals[point])
        # # print(Weld_Mesh.cell_normals[cells])
        dir=np.sum(Weld_Mesh.cell_normals[cells],0)
        # array=[0,0,0]
        # for n in cells:
        #     print(Weld_Mesh.cell[n])
        # print(point)
        # print(Weld_Mesh.point_normals[point])
        # print(Weld_Mesh.points[point])
        # print(cells)
        # print(cell_point)
        # print(cell_closest)
        arrow=pv.Arrow(P1,dir,scale=0.01)
        plotter.add_mesh(arrow,color=blue)
    Weld_Mesh_file_name='Weld_Mesh_sangam_roman_edit_v3.vtk'
    Weld_Mesh=pv.read(Weld_Mesh_file_name)
    # Weld_Mesh=Weld_Mesh.compute_normals(auto_orient_normals=True,consistent_normals=True,split_vertices=False,inplace=True)
    Weld_Mesh.plot_normals(mag=0.01,opacity=0.9)

    plotter=pv.Plotter()
    plotter.enable_point_picking(color='r',callback=query)
    # Weld_Mesh.compute_normals(inplace=True)
    # Weld_Mesh.plot_normals(opacity=0.8,mag=5)
    plotter.add_mesh(Weld_Mesh,opacity=0.8,pickable=False)

    pset=Weld_Mesh.points
    plotter.add_points(pset,point_size=20,color='y',pickable=True)
    plotter.show()