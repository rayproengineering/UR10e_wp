#!/usr/bin/env python  
import rospy

import math
import tf2_ros
import geometry_msgs.msg
import tf2_geometry_msgs
import tf2_msgs
import tf

# class tf_monitor(object):
#     def __init__(self,target,source):
#         rospy.init_node('tf2_listener'+'_'+source+'_to_'+ target)
#         tfBuffer = tf2_ros.Buffer()
#         listener = tf2_ros.TransformListener(tfBuffer)
#         rate=rospy.Rate(10)
#         while not rospy.is_shutdown():
#             try:
#                 trans = tfBuffer.lookup_transform(target, source, rospy.Time())
#             except (tf2_ros.LookupException, tf2_ros.ConnectivityException, tf2_ros.ExtrapolationException):
#                 rate.sleep()
#                 continue

#             print(trans)


if __name__ == '__main__':
    
    rospy.init_node('tf2_listener')
    


    tfBuffer = tf2_ros.Buffer()
    listener = tf2_ros.TransformListener(tfBuffer)
    # rate = rospy.Rate(100.0)
    # rate.sleep()
    
    # trans = tfBuffer.lookup_transform('tool0_controller', 'base', rospy.Time())

    # print(trans)

    # rospy.wait_for_service('spawn')
    # spawner = rospy.ServiceProxy('spawn', turtlesim.srv.Spawn)
    # turtle_name = rospy.get_param('turtle', 'turtle2')
    # spawner(4, 2, 0, turtle_name)
    # turtle_vel = rospy.Publisher('%s/cmd_vel' % turtle_name, geometry_msgs.msg.Twist, queue_size=1)
    toolframe=rospy.Publisher('Tool_Orientation',geometry_msgs.msg.Transform,queue_size=1)


    rate = rospy.Rate(10.0)
    while not rospy.is_shutdown():
        try:
            trans = tfBuffer.lookup_transform('base', 'tool0_controller', rospy.Time())
            
        except (tf2_ros.LookupException, tf2_ros.ConnectivityException, tf2_ros.ExtrapolationException):
            rate.sleep()
            continue

        # print(trans._get_types)
        
        # msg = geometry_msgs.msg.Twist()

        # msg.angular.z = 4 * math.atan2(trans.transform.translation.y, trans.transform.translation.x)
        # msg.linear.x = 0.5 * math.sqrt(trans.transform.translation.x ** 2 + trans.transform.translation.y ** 2)

        # turtle_vel.publish(msg)
        msg=geometry_msgs.msg.Transform
        msg=trans.transform
        toolframe.publish(msg)

        rate.sleep()