#!/usr/bin/env python

import networkx as nx
from networkx.algorithms import approximation
import numpy as np
import matplotlib.pyplot as plt
import scipy

    
def create_node_dict(point_list):
    node_dict={}
    for n in range(len(point_list)):
        node_dict[n]=(point_list[n])
    return node_dict

def ordered_points_tcp(dict,tour):
    points_ordered=[]
    for n in range(len(tour)):
        points_ordered.append(dict[tour[n]])
    return points_ordered


def solve_tcp(point_list):
    node_dict=create_node_dict(point_list)
    
    G = nx.complete_graph(node_dict.keys())


    # G.add_nodes_from(node_dict.keys())
    nx.set_node_attributes(G, node_dict, name='pos')



    for (u,v) in G.edges:
        # print(u)
        nx.set_edge_attributes(G,{(u,v):np.linalg.norm([node_dict[u][0]-node_dict[v][0],node_dict[u][1]-node_dict[v][1]])},'weight')
    
    
    
    tour=approximation.traveling_salesman.traveling_salesman_problem(G)
    tour_edges = list(zip(tour,tour[1:]))
    # print(tour)
    # nx.add_cycle(G,tour)
    h=nx.cycle_graph(tour)
    nx.draw_networkx(h,pos=node_dict,node_color='r',edge_color='r',width=5)
    nx.draw_networkx_nodes(G, pos=node_dict,nodelist=set(G.nodes)-set(tour))
    nx.draw_networkx_edges(G, pos=node_dict,edgelist=set(G.edges)-set(tour_edges),edge_color='b',width=0.25)
    points_ordered=ordered_points_tcp(node_dict,tour)
    


    plt.axis('equal')
    plt.show()


    


    # print(G)
    # print('hi')
    # print(G.number_of_nodes())
    # print(G.number_of_edges())
    # print(G.nodes)
    # print(G.edges)
    return tour


