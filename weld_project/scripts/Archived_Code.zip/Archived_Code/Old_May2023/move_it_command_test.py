#!/usr/bin/env python

import sys
import copy
from copy import deepcopy
import rospy
import moveit
from moveit import *
import moveit_commander
import moveit_msgs.msg
from moveit_msgs.msg import RobotState
import geometry_msgs.msg as geometry_msgs
from math import pi
from std_msgs.msg import String
from moveit_commander.conversions import pose_to_list
import numpy as np
import quad_class
from quad_class import *
import random
import TCP_test_1
from TCP_test_1 import *
# import moveit_core





def calculate_average_points(points_array):
    x_avg=0
    y_avg=0
    z_avg=0
    
    for n in range(len(points_array)):
        x_avg+=points_array[n][0]
        y_avg+=points_array[n][1]
        z_avg+=points_array[n][2]
    x_avg=x_avg/len(points_array)
    y_avg=y_avg/len(points_array)
    z_avg=z_avg/len(points_array)
    return(x_avg,y_avg,z_avg)



def extract_pose_data(Pose_List,datatype):
    
    data=[]

    if datatype=='all':
        for n in range(len(Pose_List.poses)):
            data.append(((Pose_List.poses[n].position.x, Pose_List.poses[n].position.y, Pose_List.poses[n].position.z)\
                ,(Pose_List.poses[n].orientation.x, Pose_List.poses[n].orientation.y, Pose_List.poses[n].orientation.z, Pose_List.poses[n].orientation.w)))
    if datatype=='cart':
        for n in range(len(Pose_List.poses)):
            data.append((Pose_List.poses[n].position.x, Pose_List.poses[n].position.y, Pose_List.poses[n].position.z))
    if datatype=='cart_2D':
        for n in range(len(Pose_List.poses)):
            data.append((Pose_List.poses[n].position.x, Pose_List.poses[n].position.y))     
    return(data)

def order_square_traj(square_points):
    ordered_pairs=[]
    ordered_pairs.append(square_points[0][0])
    for n in range(len(square_points[0])-1):
        distance_array=[]
        for k in range(len(square_points[0])-1):
            if ordered_pairs[n]==square_points[0][k] or square_points[0][k] in ordered_pairs:
                d1=np.inf
            else:
                d1=[abs(ordered_pairs[n][0]-square_points[0][k][0]),abs(ordered_pairs[n][0]-square_points[0][k][1])]
            distance_array.append(d1)
        index=np.argmin(distance_array)+1+n
        ordered_pairs.append(square_points[0][index])
    return ordered_pairs



    




if __name__ == "__main__":

    moveit_commander.roscpp_initialize(sys.argv)
    rospy.init_node('move_group_python', anonymous=True)

    robot = moveit_commander.RobotCommander()
    P1=[-0.60072836282,0.247189516266,0.0212301530027,0.0147089928173,-0.989562034441,-0.143318757154,0.00321859780602]
    P2=[-0.826953961051,0.0109421809065,0.0274031926709,0.737699459925,-0.663280694749,-0.0647740724994,0.107993269842]
    P3=[-0.588031247567,-0.209333998978,0.0304761134586,0.980619944194,0.0675946835278,-0.00329646331958,0.183860319639]
    P4=[-0.364119406606,0.0323842176556,0.0232494862128,0.731883073698,0.667181816445,0.133761350169,0.0363798218786]
    P5=[-0.666653385887,0.294843232047,0.0204006050429,0.755219828947,0.651070576707,0.0537385850488,0.0535002671794]
    P6=[-0.872334192188,0.0741099608542,0.0199389515739,0.967721333821,0.250061123655,-0.0198105050757,0.0243392356671]
    P7=[-1.11995577843,0.286174298311,0.0267050672064,0.745499616058,-0.63048092365,-0.188724723103,0.105390256958]
    P8=[-0.890796072075,0.519523233588,0.0261712121611,0.0131184819653,-0.979759028633,-0.193906333843,0.0479633707978]
    P9=[-0.621407742528,0.801589901105,0.035954874622,-0.0376975362769,0.971687707541,0.224261208766,0.0640999611212]
    P10=[-0.842496606305,0.57667525251,0.0258287005691,0.66844515151,-0.732714348697,-0.119728616542,0.0444502082845]
    P11=[-0.610825054401,0.344447628995,0.0265833906467,0.990877289597,-0.0687544964133,0.081677832004,0.0822420083833]
    P12=[-0.38719696171,0.585330384312,0.0223949985167,0.756919825179,0.651750414228,0.0357006087127,0.0319255750358]

    POINT1=P1
    POINT2=P2
    POINT3=P3
    POINT4=P4
    POINT5=P5
    POINT6=P6
    POINT7=P7
    POINT8=P8
    POINT9=P1
    POINT10=P10
    POINT11=P11
    POINT12=P12
    
    Pose1=geometry_msgs.Pose(geometry_msgs.Vector3(POINT1[0], POINT1[1], POINT1[2]), \
        geometry_msgs.Quaternion(POINT1[3], POINT1[4], POINT1[5],POINT1[6]))
    Pose2=geometry_msgs.Pose(geometry_msgs.Vector3(POINT2[0], POINT2[1], POINT2[2]), \
        geometry_msgs.Quaternion(POINT2[3], POINT2[4], POINT2[5],POINT2[6]))
    Pose3=geometry_msgs.Pose(geometry_msgs.Vector3(POINT3[0], POINT3[1], POINT3[2]), \
        geometry_msgs.Quaternion(POINT3[3], POINT3[4], POINT3[5],POINT3[6]))
    Pose4=geometry_msgs.Pose(geometry_msgs.Vector3(POINT4[0], POINT4[1], POINT4[2]), \
        geometry_msgs.Quaternion(POINT4[3], POINT4[4], POINT4[5],POINT4[6]))
    Pose5=geometry_msgs.Pose(geometry_msgs.Vector3(POINT5[0], POINT5[1], POINT5[2]), \
        geometry_msgs.Quaternion(POINT5[3], POINT5[4], POINT5[5],POINT5[6]))
    Pose6=geometry_msgs.Pose(geometry_msgs.Vector3(POINT6[0], POINT6[1], POINT6[2]), \
        geometry_msgs.Quaternion(POINT6[3], POINT6[4], POINT6[5],POINT6[6]))
    Pose7=geometry_msgs.Pose(geometry_msgs.Vector3(POINT7[0], POINT7[1], POINT7[2]), \
        geometry_msgs.Quaternion(POINT7[3], POINT7[4], POINT7[5],POINT7[6]))
    Pose8=geometry_msgs.Pose(geometry_msgs.Vector3(POINT8[0], POINT8[1], POINT8[2]), \
        geometry_msgs.Quaternion(POINT8[3], POINT8[4], POINT8[5],POINT8[6]))
    Pose9=geometry_msgs.Pose(geometry_msgs.Vector3(POINT9[0], POINT9[1], POINT9[2]), \
        geometry_msgs.Quaternion(POINT9[3], POINT9[4], POINT9[5],POINT9[6]))
    Pose10=geometry_msgs.Pose(geometry_msgs.Vector3(POINT10[0], POINT10[1], POINT10[2]), \
        geometry_msgs.Quaternion(POINT10[3], POINT10[4], POINT10[5],POINT10[6]))
    Pose11=geometry_msgs.Pose(geometry_msgs.Vector3(POINT11[0], POINT11[1], POINT11[2]), \
        geometry_msgs.Quaternion(POINT11[3], POINT11[4], POINT11[5],POINT11[6]))
    Pose12=geometry_msgs.Pose(geometry_msgs.Vector3(POINT12[0], POINT12[1], POINT12[2]), \
        geometry_msgs.Quaternion(POINT12[3], POINT12[4], POINT12[5],POINT12[6]))
    

    Pose_Array=geometry_msgs.PoseArray()
    Pose_Array.poses=[Pose1,Pose2,Pose3,Pose4,Pose5,Pose6,Pose7,Pose8,Pose9,Pose10,Pose11,Pose12]
    # print(Pose_Array)

    cart_points=extract_pose_data(Pose_Array,'cart')
    # print(cart_points)

    average_point=calculate_average_points(cart_points)
    print('Average POINT:')
    print(average_point)

    # print(extract_pose_data(Pose_Array,'cart_2D'))

    # square_points=(get_squares(extract_pose_data(Pose_Array,'cart_2D')))
    # cart_data=extract_pose_data(Pose_Array,'cart_2D')
    # print(square_points[0])

    # ord=order_square_traj(square_points)

    pose_dict={}
    for n in range(len(Pose_Array.poses)):
        key=(Pose_Array.poses[n].position.x,Pose_Array.poses[n].position.y)
        pose_dict[key]=Pose_Array.poses[n]
    
    # print(list(pose_dict.keys()))
    pose_key_list=list(pose_dict.keys())

    tour=solve_tcp(list(pose_key_list))

    group_name = "manipulator"
    move_group = moveit_commander.MoveGroupCommander(group_name)
    display_trajectory_publisher = rospy.Publisher('/move_group/display_planned_path',moveit_msgs.msg.DisplayTrajectory,queue_size=20)

    move_group.clear_pose_targets()
    planning_frame = move_group.get_planning_frame()
    # print('PLANNING FRAME:')
    # print(planning_frame)
    joint_goal = move_group.get_current_joint_values()
    joint_goal[0] = (np.radians(180))
    joint_goal[1] = (np.radians(-90))
    joint_goal[2] = (np.radians(90))
    joint_goal[3] = (np.radians(90))
    joint_goal[4] = (np.radians(90))
    joint_goal[5] = (np.radians(180))




    move_group.go(joint_goal, wait=True)
    move_group.stop()
    
    move_group.clear_pose_targets()
    move_group.stop()
    
    home=move_group.get_current_pose().pose
    
    pose_goal = geometry_msgs.Pose()
    
    pose_goal.orientation = home.orientation
    pose_goal.position.x = average_point[0]
    
    pose_goal.position.y = average_point[1]
    
    pose_goal.position.z = average_point[2]+0.05
    
    move_group.set_pose_target(pose_goal)

    success = move_group.go(wait=True)
    
    move_group.stop()
    move_group.clear_pose_targets()


    move_group.stop()

    # home=move_group.get_current_pose().pose

    # pose_goal = geometry_msgs.Pose()

    # pose_goal.orientation = home.orientation



    # current_pose = move_group.get_current_pose().pose
    for n in range(len(tour)):
        pose_goal1 = geometry_msgs.Pose()
        # pose_goal1.orientation=home.orientation
        pose_goal1 = deepcopy(pose_dict[pose_key_list[tour[n]]])
        move_group.set_pose_target(deepcopy(pose_goal1))
        move_group.go(wait=True)
        move_group.stop()
        move_group.clear_pose_targets()
        move_group.stop()
            
    




    
    # move_group.set_pose_target(pose_goal)

    # success = move_group.go(wait=True)
    # # Calling `stop()` ensures that there is no residual movement
    # move_group.stop()
    # # It is always good to clear your targets after planning with poses.
    # # Note: there is no equivalent function for clear_joint_value_targets().
    # move_group.clear_pose_targets()


    
    # # Calling `stop()` ensures that there is no residual movement
    # move_group.stop()
    # # It is always good to clear your targets after planning with poses.
    # # Note: there is no equivalent function for clear_joint_value_targets().
    # move_group.clear_pose_targets()
    # current_pose = move_group.get_current_pose().pose
    # waypoints = []
    

    # x_points=np.linspace(current_pose.position.x,pose_dict[ord[1]].position.x,5)
    # y_points=np.linspace(current_pose.position.y,pose_dict[ord[1]].position.y,5)
    # z_points=np.linspace(current_pose.position.z,pose_dict[ord[1]].position.z,5)
    # xw_points=np.linspace(current_pose.orientation.x,pose_dict[ord[1]].orientation.x,5)
    # yw_points=np.linspace(current_pose.orientation.y,pose_dict[ord[1]].orientation.y,5)
    # zw_points=np.linspace(current_pose.orientation.z,pose_dict[ord[1]].orientation.z,5)
    # ww_points=np.linspace(current_pose.orientation.w,pose_dict[ord[1]].orientation.w,5)

    # for n in range(len(x_points)):
    #     pose_goal = geometry_msgs.Pose()
    #     # pose_goal.orientation.w = 1
    #     pose_goal.position.x = x_points[n]
    #     pose_goal.position.y = y_points[n]
    #     pose_goal.position.z = z_points[n]

    #     pose_goal.orientation.x = xw_points[n]
    #     pose_goal.orientation.y = yw_points[n]
    #     pose_goal.orientation.z = zw_points[n]
    #     pose_goal.orientation.w = ww_points[n]
    #     waypoints.append(deepcopy(pose_goal))

    # (plan1, fraction) = move_group.compute_cartesian_path(
    #                                 deepcopy(waypoints),   # waypoints to follow
    #                                 0.001,        # eef_step
    #                                 0.0)         # jump_threshold

    # move_group.execute(plan1, wait=True)
    # # move_gro?up.wait()
    # move_group.stop()
    # move_group.clear_pose_targets()
    # move_group.stop()
    # current_pose = move_group.get_current_pose().pose
    # waypoints = []


    # x_points=np.linspace(current_pose.position.x,pose_dict[ord[2]].position.x,5)
    # y_points=np.linspace(current_pose.position.y,pose_dict[ord[2]].position.y,5)
    # z_points=np.linspace(current_pose.position.z,pose_dict[ord[2]].position.z,5)
    # xw_points=np.linspace(current_pose.orientation.x,pose_dict[ord[2]].orientation.x,5)
    # yw_points=np.linspace(current_pose.orientation.y,pose_dict[ord[2]].orientation.y,5)
    # zw_points=np.linspace(current_pose.orientation.z,pose_dict[ord[2]].orientation.z,5)
    # ww_points=np.linspace(current_pose.orientation.w,pose_dict[ord[2]].orientation.w,5)
    # for n in range(len(x_points)):
    #     pose_goal = geometry_msgs.Pose()
    #     # pose_goal.orientation.w = 1
        
    #     pose_goal.position.x = x_points[n]
    #     pose_goal.position.y = y_points[n]
    #     pose_goal.position.z = z_points[n]
    #     pose_goal.orientation.x = xw_points[n]
    #     pose_goal.orientation.y = yw_points[n]
    #     pose_goal.orientation.z = zw_points[n]
    #     pose_goal.orientation.w = ww_points[n]
    #     waypoints.append(deepcopy(pose_goal))

    # (plan2, fraction) = move_group.compute_cartesian_path(
    #                                 deepcopy(waypoints),   # waypoints to follow
    #                                 0.001,        # eef_step
    #                                 0.0)         # jump_threshold


    # move_group.execute(plan2, wait=True)
    # move_group.stop()
    # move_group.clear_pose_targets()
    # current_pose = move_group.get_current_pose().pose
    # waypoints = []

    # x_points=np.linspace(current_pose.position.x,pose_dict[ord[3]].position.x,5)
    # y_points=np.linspace(current_pose.position.y,pose_dict[ord[3]].position.y,5)
    # z_points=np.linspace(current_pose.position.z,pose_dict[ord[3]].position.z,5)
    # xw_points=np.linspace(current_pose.orientation.x,pose_dict[ord[3]].orientation.x,5)
    # yw_points=np.linspace(current_pose.orientation.y,pose_dict[ord[3]].orientation.y,5)
    # zw_points=np.linspace(current_pose.orientation.z,pose_dict[ord[3]].orientation.z,5)
    # ww_points=np.linspace(current_pose.orientation.w,pose_dict[ord[3]].orientation.w,5)
    # for n in range(len(x_points)):
    #     pose_goal = geometry_msgs.Pose()
    #     # pose_goal.orientation.w = 1
    #     pose_goal.position.x = x_points[n]
    #     pose_goal.position.y = y_points[n]
    #     pose_goal.position.z = z_points[n]
    #     pose_goal.orientation.x = xw_points[n]
    #     pose_goal.orientation.y = yw_points[n]
    #     pose_goal.orientation.z = zw_points[n]
    #     pose_goal.orientation.w = ww_points[n]
    #     waypoints.append(deepcopy(pose_goal))

    # (plan3, fraction) = move_group.compute_cartesian_path(
    #                                 deepcopy(waypoints),   # waypoints to follow
    #                                 0.001,        # eef_step
    #                                 0.0)         # jump_threshold


    # move_group.execute(plan3, wait=True)
    # move_group.stop()
    # move_group.clear_pose_targets()
    # current_pose = move_group.get_current_pose().pose
    # waypoints = []

    

    # x_points=np.linspace(current_pose.position.x,pose_dict[ord[0]].position.x,5)
    # y_points=np.linspace(current_pose.position.y,pose_dict[ord[0]].position.y,5)
    # z_points=np.linspace(current_pose.position.z,pose_dict[ord[0]].position.z,5)
    # xw_points=np.linspace(current_pose.orientation.x,pose_dict[ord[0]].orientation.x,5)
    # yw_points=np.linspace(current_pose.orientation.y,pose_dict[ord[0]].orientation.y,5)
    # zw_points=np.linspace(current_pose.orientation.z,pose_dict[ord[0]].orientation.z)
    # ww_points=np.linspace(current_pose.orientation.w,pose_dict[ord[0]].orientation.w,5)
    # for n in range(len(x_points)):
    #     pose_goal = geometry_msgs.Pose()
    #     # pose_goal.orientation.w = 1
    #     pose_goal.position.x = x_points[n]
    #     pose_goal.position.y = y_points[n]
    #     pose_goal.position.z = z_points[n]
    #     pose_goal.orientation.x = xw_points[n]
    #     pose_goal.orientation.y = yw_points[n]
    #     pose_goal.orientation.z = zw_points[n]
    #     pose_goal.orientation.w = ww_points[n]
    #     waypoints.append(deepcopy(pose_goal))

    # (plan4, fraction) = move_group.compute_cartesian_path(
    #                                 deepcopy(waypoints),   # waypoints to follow
    #                                 0.001,        # eef_step
    #                                 0.0)         # jump_threshold

    # move_group.execute(plan4, wait=True)
    # # move_group.wait()
    # move_group.stop()
    # move_group.clear_pose_targets()

    # waypoints = []




    
    # pose_goal = geometry_msgs.Pose()
    # pose_goal.orientation = home.orientation
    # pose_goal.position.x = average_point[0]
    # pose_goal.position.y = average_point[1]
    # pose_goal.position.z = average_point[2]+0.1

    # x_points=np.linspace(current_pose.position.x,pose_goal.position.x,5)
    # y_points=np.linspace(current_pose.position.y,pose_goal.position.y,5)
    # z_points=np.linspace(current_pose.position.z,pose_goal.position.z,5)

    # for n in range(len(x_points)):
    #     pose_goal = geometry_msgs.Pose()
    #     pose_goal.orientation.x = home.orientation.x
    #     pose_goal.orientation.y = home.orientation.y
    #     pose_goal.orientation.z = home.orientation.z
    #     pose_goal.position.x = x_points[n]
    #     pose_goal.position.y = y_points[n]
    #     pose_goal.position.z = z_points[n]
    #     waypoints.append(deepcopy(pose_goal))
    
    
    
    # (plan5, fraction) = move_group.compute_cartesian_path(
    #                                 deepcopy(waypoints),   # waypoints to follow
    #                                 0.001,        # eef_step
    #                                 0.0)         # jump_threshold

    # move_group.execute(plan5, wait=True)
    # move_group.stop()
    # move_group.clear_pose_targets()
   