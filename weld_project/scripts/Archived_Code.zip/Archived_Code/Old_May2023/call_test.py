#!/usr/bin/env python
import rospy
import sys
import tf2_ros
import geometry_msgs.msg as geometry_msgs
import numpy as np
import test
import move_module
from move_module import *

if __name__ == "__main__":
    p,d=test.get_points()
    # print(p)
    # print(d)
    

        



