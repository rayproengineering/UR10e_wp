import numpy as np
import math
import time
import isinside
from isinside import *

def orientation(p, q, r):
    val = (q[1] - p[1]) * (r[0] - q[0]) - (q[0] - p[0]) * (r[1] - q[1])
    # print('Value')
    # print(val)
 
    if val == 0:
        return 0
 
    if val > 0:
        return 1
    else:
        return 2

def doIntersect(p1,q1,p2,q2):
    # print(sq_points)
    o1 = orientation(p1, q1, p2)
    o2 = orientation(p1, q1, q2)
    o3 = orientation(p2, q2, p1)
    o4 = orientation(p2, q2, q1)
 
    if o1==0 or o2==0 or o3==0 or o4==0:
        return False
    
    if o1 != o2 and o3 != o4:
        return True
 
    return False

def similar(p1, p2):
    # it is same, we are returning false because
    # quadrilateral is not possible in this case
    if (p1.x == p2.x and p1.y == p2.y):
        return False
 
    # it is not same, So there is a
    # possibility of a quadrilateral
    return True

# check for collinearity
def collinear(p1, p2, p3):
    x1 = p1[0]
    y1 = p1[1]
    x2 = p2[0]
    y2 = p2[1]
    x3 = p3[0]
    y3 = p3[1]
 
    # it is collinear, we are returning true
    # because quadrilateral is not possible in this case
    if (y3 - y2) * (x2 - x1) == (y2 - y1) * (x3 - x2):
        return True
 
    else:
        return False

# def no_of_quads(p1, p2, p3, p4):
#     # ** Checking for cases where no quadrilateral = 0 **
 
#     # check if any of the points are same
#     same = True
#     same = same & similar(p1, p2)
#     same = same & similar(p1, p3)
#     same = same & similar(p1, p4)
#     same = same & similar(p2, p3)
#     same = same & similar(p2, p4)
#     same = same & similar(p3, p4)
 
#     # similar points exist
#     if (same == False):
#         return 0
 
#     # check for collinearity
#     coll = True
#     coll = coll & collinear(p1, p2, p3)
#     coll = coll & collinear(p1, p2, p4)
#     coll = coll & collinear(p1, p3, p4)
#     coll = coll & collinear(p2, p3, p4)
 
#     # points are collinear
#     if (coll == False):
#         return 0
 
#     # ** Checking for cases where no of quadrilaterals= 1 or 3 **
 
#     check = 0
 
#     if doIntersect(p1, p2, p3, p4):
#         check = 1
#     if doIntersect(p1, p3, p2, p4):
#         check = 1
#     if doIntersect(p1, p2, p4, p3):
#         check = 1
 
#     if (check == 0):
#         return 3
#     return 1

def is_convex_non_col(sq_points):
    [p1, p2, p3, p4]=[sq_points[0],sq_points[1],sq_points[2],sq_points[3]]
    check = 0
    # print(p1)
    # coll = True
    # coll = coll & collinear(p1, p2, p3)
    # coll = coll & collinear(p1, p2, p4)
    # coll = coll & collinear(p1, p3, p4)
    # coll = coll & collinear(p2, p3, p4)
    # if (coll == False):
    #     return False

    if doIntersect(p1, p2, p3, p4):
        # print('hi')
        check = 1
    if doIntersect(p1, p3, p2, p4):
        # print('roman')
        check = 1
    if doIntersect(p1, p4, p2, p3):
        # print('sucks')
        check = 1
    if (check == 0):
        return False
        
    return True

def get_triangle_area(tri):
    a=tri[0]
    b=tri[1]
    c=tri[2]
    area = 0.5*(a[0]*(b[1]-c[1])+b[0]*(c[1]-a[1])+c[0]*(a[1]-b[1]))
    return (abs(area))

def get_triangles(rect):
    tri1=(rect[0],rect[1],rect[2])
    #find a valid triangle
    tri2=(rect[1],rect[2],rect[3])
    if doIntersect(rect[0],rect[2],rect[1],rect[3]) or doIntersect(rect[0],rect[1],rect[2],rect[3]):
        tri2=(rect[0],rect[2],rect[3])
        if doIntersect(rect[0],rect[3],rect[1],rect[2]) or doIntersect(rect[2],rect[3],rect[0],rect[1]):
            tri2=(rect[0],rect[1],rect[3])
    return tri1,tri2


def points_within(given_points,rect):
    # areat1=get_triangle_area(rect[0],rect[1],rect[2])
    # areat2=get_triangle_area(rect[1],rect[2],rect[3])
    # print('area 1')
    # print(areat1)
    # print(rect)
    tri1,tri2=get_triangles(rect)
    # print(tri1)
    # print(tri2)
    # print(tri1)

    # print('area 2')
    # print(areat2)

    # areaquad=areat1+areat2
    if not(good_square(tri1,tri2,rect)):
        # print('hi')
        # print('False')
        return [1, 0]
        # print('bye')



    for n in range(len(given_points)):
        # print(rect)
        # print(given_points[n])
        # print(given_points[n] in rect)
        


        if not(given_points[n] in rect) :
            pass
            # areat1p=get_triangle_area(rect[0],rect[1],given_points[n])
            # areat2p=get_triangle_area(rect[1],rect[2],given_points[n])
            # areat3p=get_triangle_area(rect[2],rect[0],given_points[n])
            # a1=areat1p+areat2p+areat3p
            # print('a1')
            # print(a1)
            

            # areat4p=get_triangle_area(rect[1],rect[2],given_points[n])
            # areat5p=get_triangle_area(rect[2],rect[3],given_points[n])
            # areat6p=get_triangle_area(rect[1],rect[3],given_points[n])
            # a2=areat4p+areat5p+areat6p
            # print('a2')
            # print(a2)

            if (checkInside(tri1,given_points[n])):

                
                return [1, 0]
            if (checkInside(tri2,given_points[n])):
                



                return [1, 0]
            # print('ROMEDAWGS')

            # if (abs(a1-areat1)<=0 or abs(a2-areat2)<=0):
            #     return False
            # if (collinear(rect[0],rect[1], given_points[n]) \
            #     or collinear(rect[1],rect[2], given_points[n]) or collinear(rect[2],rect[3], given_points[n]) or collinear(rect[3],rect[1], given_points[n]) \
            #     or collinear(rect[3],rect[0], given_points[n])):
            #     return False
    # print(tri1)
    # print(tri2)
    # print('hellloooo helllooo')

    return [0, (get_triangle_area(tri1)+get_triangle_area(tri2))]
    
def lawofcos(tri1):
    v1=[abs(tri1[0][0]-tri1[1][0]),abs(tri1[0][1]-tri1[1][1])]
    v2=[abs(tri1[1][0]-tri1[2][0]),abs(tri1[1][1]-tri1[2][1])]
    v3=[abs(tri1[2][0]-tri1[0][0]),abs(tri1[2][1]-tri1[0][1])]
    l1=np.linalg.norm(v1,2)
    l2=np.linalg.norm(v2,2)
    l3=np.linalg.norm(v3,2)
    ang1=np.degrees(np.arccos( (l1*l1+l2*l2-l3*l3) /(2*l1*l2)))
    ang2=np.degrees(np.arccos( (l2*l2+l3*l3-l1*l1) /(2*l2*l3)))
    ang3=np.degrees(np.arccos( (l1*l1+l3*l3-l2*l2) /(2*l1*l3)))
    return[ang1,ang2,ang3]





def good_square(tri1,tri2,rect):

    v1=[abs(tri1[0][0]-tri1[1][0]),abs(tri1[0][1]-tri1[1][1])]
    v2=[abs(tri1[1][0]-tri1[2][0]),abs(tri1[1][1]-tri1[2][1])]
    v3=[abs(tri1[2][0]-tri1[0][0]),abs(tri1[2][1]-tri1[0][1])]
    v4=[abs(tri2[0][0]-tri2[1][0]),abs(tri2[0][1]-tri2[1][1])]
    v5=[abs(tri2[1][0]-tri2[2][0]),abs(tri2[1][1]-tri2[2][1])]
    v6=[abs(tri2[2][0]-tri2[0][0]),abs(tri2[2][1]-tri2[0][1])]
    # print(v1)
    # v4=abs(tri2[0]-tri2[1])
    # v5=abs(tri2[1]-tri2[2])
    # v6=abs(tri2[2]-tri2[0])
    
    lengths=[np.linalg.norm(v1,2),np.linalg.norm(v2,2),np.linalg.norm(v3,2)]
    lengths2=[np.linalg.norm(v4,2),np.linalg.norm(v5,2),np.linalg.norm(v6,2)]
    # v1=v1/lengths[0]
    # v2=v2/lengths[1]
    # v3=v3/lengths[2]
    # v4=v4/np.linalg.norm(v4,2)
    # v5=v5/np.linalg.norm(v5,2)
    # v6=v6/np.linalg.norm(v6,2)
    # tri1a1=np.arccos(np.dot(v1,v2))
    # tri1a2=np.arccos(np.dot(v2,v3))
    # tri1a3=np.arccos(np.dot(v3,v1))
    # # tri2a1=
    # tri2a2=
    # tri2a3=
    shared=[]
    b=0
    for k in range(len(tri1)):
        if b==1:
            break
        for q in range(len(tri2)):
            if tri1[k]==tri2[q]:
                shared.append(tri2[q])
            if len(shared)==2:
                b=1
                break

    share=[abs(shared[0][0]-shared[1][0]),(shared[0][1]-shared[1][1])]
        
    sharelength=np.linalg.norm(share,2)
    # ang=np.degrees([tri1a1,tri1a2,tri1a3])
    # print('HI')
    ang=lawofcos(tri1)
    # print(sharelength)
    # print(lengths)
    # print(lengths2)
    # print(tri1)
    # print(tri2)
    # print(ang)
    # print(np.degrees(ang))
    for n in range(len(ang)):
        if 85<=ang[n]<=95:

            # print('HI')
            # print(rect)
            # print(ang)
            # print(tri1)
            # print(tri2)
            # # print('hi')
            # elements=rect
            # if (5,2) in elements and (8,2) in elements and (5,1) in elements and (8,1) in elements:
                # print('HERE')
                # print('hi')
                # print(elements)
                # print(tri1)
                # print(tri2)
                # print(shared)
                # print(share)
                # print(sharelength)
                # print(lengths)
                # print(lengths2)
                # print(np.max(lengths))
                # print(np.max(lengths2))
            if (abs(sharelength-np.max(lengths))<=0.001) and (abs(sharelength-np.max(lengths2))<=0.001):
                # print('hi')

                # if tri1==((1, 2), (1, 3), (4, 2)) and tri2==((1, 2), (4, 2), (5, 1)):
                #     print('exit')
                #     exit()
                return 1
    return 0




def get_squares(points):
    # points=list(set(points))
    combinations=[]
    areas=[]
    # print(len(points))
    # total_unique=math.factorial(len(points))/(math.factorial(4)*math.factorial(len(points)-4))
    b=0
    for n1 in range(len(points)):
        p1=points[n1]
        if b==1:
            break
        for n2 in range(len(points)):
            p2=points[n2]
            if b==1:
                break
            for n3 in range(len(points)):
                p3=points[n3]
                if b==1:
                    break
                for n4 in range(len(points)):
                    p4=points[n4]
                    if not(p1==p2) and not(p1==p3) and not(p1==p4) and not(p2==p3) and not(p2==p4) and not(p3==p4):
                        elements=[p1,p2,p3,p4]
                        # print(elements)
                        indexs=np.array([n1,n2,n3,n4])
                        indexs=np.argsort(indexs)
                        elements=tuple([elements[indexs[0]],elements[indexs[1]],elements[indexs[2]],elements[indexs[3]]])
                        bool=is_convex_non_col(elements)
                        # print(bool)

                        if not(elements in combinations[:]) and (bool):
                            # print(elements)
                            data=points_within(points,elements)

                            if not(data[0]):
                                combinations.append(elements)
                                areas.append(data[1])
    # print(combinations)
    # print(areas)
    # print(len(combinations))
    
    if not(len(points)==4):
        index_list = np.array(areas).argsort().tolist()[::-1]
        # print(index_list)
        nos=len(points)/4
        stw=[]
        for n in range(nos):
            stw.append(combinations[index_list[n]])
            # print(areas[index_list[n]])
        return(stw)
    else:
        return(combinations)
        


given_points = [(0.3744506348438836, -0.001475861571727518), (1.1108280667053678, -0.28079354060441775), \
    (0.8818524625958813, -0.05395679294468539), (0.667736447956563, -0.27405340821159563), \
        (0.8848905267581048, -0.497569061295335), (0.6160631791920623, 0.24162969059377967), \
            (0.6057962033103819, -0.21904917168314805), (0.8358787510891118, 0.007686454327319785)]
given_points=[(0.617839728606, 0.224477653534), (0.840401886433, -0.0124632838463), (0.384845057446, -0.0155185997258), (0.615577088175, -0.233837352941)]
rect=[(0.6160631791920623, 0.24162969059377967),(0.8358787510891118, 0.007686454327319785),(0.6057962033103819, -0.21904917168314805),(0.3744506348438836, -0.001475861571727518)]
# tri1,tri2=get_triangles(rect)
# print(tri1)
# print(tri2)
# print(lawofcos(tri1))
# print(lawofcos(tri2))
# exit()
# good_square(tri1,tri2,rect)



# for n in range(len(given_points)):

#     if not(given_points[n] in rect):
#                 # areat1p=get_triangle_area(rect[0],rect[1],given_points[n])
#                 # areat2p=get_triangle_area(rect[1],rect[2],given_points[n])
#                 # areat3p=get_triangle_area(rect[2],rect[0],given_points[n])
#                 # a1=areat1p+areat2p+areat3p
#                 # print('a1')
#                 # print(a1)
                

#                 # areat4p=get_triangle_area(rect[1],rect[2],given_points[n])
#                 # areat5p=get_triangle_area(rect[2],rect[3],given_points[n])
#                 # areat6p=get_triangle_area(rect[1],rect[3],given_points[n])
#                 # a2=areat4p+areat5p+areat6p
#                 # print('a2')
#                 # print(a2)

                
                

#                 if (checkInside(tri1,given_points[n])):

                    
#                     print('poop1')
#                 if (checkInside(tri2,given_points[n])):
                    

#                     print('poop2')

# x=get_squares(given_points)
# # print(len(x))
# print(x)
