#!/usr/bin/env python


import sys
import move_module
from move_module import TrajectoryClient


if __name__ == "__main__":
    client = TrajectoryClient()

    # The controller choice is obviously not required to move the robot. It is a part of this demo
    # script in order to show all available trajectory controllers.
    # position_list = [[ -1.5571940702250977, 1.4519906044006348,1.7188285032855433, -1.7982689342894496, 3.900522232055664, 0.07666826248168945]]
    # position_list.append([1.1900962034808558, -1.557145432834961, 1.9734063148498535, -1.7980896435179652, 3.90041446685791, 0.07607126235961914+0.0872665])
    # position_list.append([1.1900962034808558, -1.557145432834961, 1.9734063148498535, -1.7980896435179652, 3.90041446685791, 0.07607126235961914-0.0872665])
    #  - shoulder_pan_joint
    #  - shoulder_lift_joint
    #  - elbow_joint
    #  - wrist_1_joint
    #  - wrist_2_joint
    #  - wrist_3_joint
    [elbow_joint, shoulder_lift_joint, shoulder_pan_joint, wrist_1_joint, wrist_2_joint,wrist_3_joint]=[1.4120448271380823, -1.5638507169536133, 2.503710985183716, -1.2495363515666504, 4.576622009277344, 0.07727813720703125]
    position_list=[[shoulder_pan_joint,shoulder_lift_joint,elbow_joint,wrist_1_joint,wrist_2_joint,wrist_3_joint]]
    position_list.append([shoulder_pan_joint,shoulder_lift_joint,elbow_joint,wrist_1_joint,wrist_2_joint,wrist_3_joint+5*0.0872665])


    # position_list = [[1.7188285032855433,1.4519906044006348,-1.5571940702250977, -1.7982689342894496, 3.900522232055664, 0.07666826248168945]]
    duration_list = [3.0, 6.0]

    # client.send_joint_trajectory(position_list,duration_list)
    client.send_cartesian_trajectory(1,3)


    
    # trajectory_type = client.choose_controller()


    # if trajectory_type == "joint_based":
    #     client.send_joint_trajectory(position_list,duration_list)
    # elif trajectory_type == "cartesian":
    #     client.send_cartesian_trajectory()
    # else:
    #     raise ValueError(
    #         "I only understand types 'joint_based' and 'cartesian', but got '{}'".format(
    #             trajectory_type
    #         )
    #     )
