#!/usr/bin/env python
import rospy
import sys
import tf2_ros
import geometry_msgs.msg as geometry_msgs
import numpy as np
import quad_class
# from quad_class import *
import sys
import copy
import rospy
import moveit_commander
import moveit_msgs.msg
from moveit_msgs.msg import RobotState
import geometry_msgs.msg as geometry_msgs
from math import pi
from std_msgs.msg import String
from moveit_commander.conversions import pose_to_list
# from cartesian_control_msgs.msg import (
#     CartesianTrajectory
# )
# import rosbag

def get_points():
        moveit_commander.roscpp_initialize(sys.argv)
        rospy.init_node('take_points', anonymous=True)

        robot = moveit_commander.RobotCommander()
        group_name = "manipulator"
        move_group = moveit_commander.MoveGroupCommander(group_name)
        rate = rospy.Rate(10)
        points = []
        v = 0
        pub= rospy.Publisher('desired_points', geometry_msgs.PoseArray ,queue_size=10)
        # bag= rosbag.Bag('test.bag','w')
        msg= geometry_msgs.PoseArray()
        while not rospy.is_shutdown():
            get = input("Press Enter, Type e to exit to Take a Point:")
            if get == "":
                try:
                    point=move_group.get_current_pose().pose
                    # point=extract_pose_data(point,'all')
                    # print(point)

                    # pose = geometry_msgs.Pose(geometry_msgs.Vector3(point[0][0]*-1, point[0][1]*-1, point[0][2]),\
                    # geometry_msgs.Quaternion(point[0][3], point[0][4], point[0][5], point[0][6]))
                    # print(point.position.x)
                    # key=(point.position.x,point.position.y)
                    # print(key)
                    points.append(point)
                    print(point)
                    # v += 1
                except rospy.ROSInterruptException:
                    pass
            elif input == 'e':
                break
            rate.sleep()
        # durationlist = np.linspace(5, 5*(v+1), v)



        msg.poses=points
        rospy.sleep(10)
        
        
        
        
        while not rospy.is_shutdown():
            pub.publish(msg)
            rate.sleep()
            rospy.loginfo_once(msg)
        
        # bag.write('points_des', msg)
        # bag.close





        # return points, durationlist
        # rospy.kill()

def extract_pose_data(Pose,datatype):
    
    data=[]

    data.append((Pose.position.x, Pose.position.y, Pose.position.z\
        ,Pose.orientation.x, Pose.orientation.y, Pose.orientation.z, Pose.orientation.w))
    
    return(data)

# def get_transform():
#     tfBuffer = tf2_ros.Buffer()
#     listener = tf2_ros.TransformListener(tfBuffer)

#     rate = rospy.Rate(10.0)
#     t = True
#     while t:
#         try:
#             trans = tfBuffer.lookup_transform('base_link', 'tool0', rospy.Time())
#             t = False

#         except (tf2_ros.LookupException, tf2_ros.ConnectivityException, tf2_ros.ExtrapolationException):
#                 rate.sleep()

#             # print(trans._get_types)

#             # msg = geometry_msgs.msg.Twist()

#             # msg.angular.z = 4 * math.atan2(trans.transform.translation.y, trans.transform.translation.x)
#             # msg.linear.x = 0.5 * math.sqrt(trans.transform.translation.x ** 2 + trans.transform.translation.y ** 2)

#     pose = geometry_msgs.Pose(geometry_msgs.Vector3(trans.transform.translation.x, trans.transform.translation.y, trans.transform.translation.z), geometry_msgs.Quaternion(trans.transform.rotation.x, trans.transform.rotation.y, trans.transform.rotation.z, trans.transform.rotation.w))
#     return pose

# def finish_traj(soo,points):
#     x_avg=0
#     y_avg=0
#     z_avg=0
#     keys=points.keys()
#     pose_list=[]
#     for t in range(len(keys)):
#         z_avg+=points[keys[t]].position.z
#         x_avg+=points[keys[t]].position.x
#         y_avg+=points[keys[t]].position.y
#     z_avg=z_avg/len(keys)
#     y_avg=y_avg/len(keys)
#     x_avg=x_avg/len(keys)
#     pose_home=geometry_msgs.Pose(geometry_msgs.Vector3(x_avg, y_avg, z_avg+0.1), geometry_msgs.Quaternion(-0.834660534945,-0.550764731788,2.96172667578e-05,2.73302570775e-05))
#     # for n in range(len(soo)):
#     #     for k in range(len(soo[n])):
#     #         print(k)
#     #         if k==0:
#     #             pose_list.append(points[soo[n][k]])
#     #             first_point=points[soo[n][k]]
#     #         if k==1:
#     #             v1=[abs(soo[n][1][0]-soo[n][0][0]),abs(soo[n][1][1]-soo[n][0][1])]
#     #             v2=[abs(soo[n][1][0]-soo[n][2][0]),abs(soo[n][1][1]-soo[n][2][1])]
#     #             v3=[abs(soo[n][1][0]-soo[n][3][0]),abs(soo[n][1][1]-soo[n][3][1])]
#     #             d1=np.linalg.norm(v1,2)
#     #             d2=np.linalg.norm(v2,2)
#     #             d3=np.linalg.norm(v3,2)
#     #             distance_list=[d1,d2,d3]
#     #             last_point=soo[n][np.argmin(distance_list)]
#     #             pose_list.append(points[last_point])
#     #         else:
#     #             for l in range(len(soo[n])):
#     #                 if l==

#     #             v1=[abs(last_point[0]-soo[n][0][0]),abs(last_point[n][1][1]-soo[n][0][1])]
#     #             v2=[abs(last_point[0]-soo[n][2][0]),abs(last_point[n][1][1]-soo[n][2][1])]
#     #             v3=[abs(last_point[0]-soo[n][3][0]),abs(last_point[n][1][1]-soo[n][3][1])]
#     #             d1=np.linalg.norm(v1,2)
#     #             d2=np.linalg.norm(v2,2)
#     #             d3=np.linalg.norm(v3,2)
#     #             index_list = np.array(distance_list).argsort().tolist()[::-1]

            


#     return [pose_home]



# if __name__ == "__main__":
    # p = pointstaker()
    # print(p)
