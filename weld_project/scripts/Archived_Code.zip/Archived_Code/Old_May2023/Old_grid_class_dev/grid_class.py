#!/usr/bin/env python3

import pyvista as pv
import  numpy as np
import networkx as nx
from networkx.algorithms import approximation
import scipy
from scipy.interpolate import make_smoothing_spline
from copy import deepcopy

import rospy
from trac_ik_python.trac_ik import IK
import moveit_commander
import geometry_msgs.msg as geometry_msgs
import sys
import moveit_msgs.msg
from std_msgs.msg import String
from moveit_commander.conversions import pose_to_list

import matplotlib as mpl
import matplotlib.pyplot as plt

def make_uneven_array(interval,long,short):
    corn=[0]
    for n in range(int(interval)):
        if ((n+1)%2)==0:
            corn.append(corn[n]+short)
        else:
            corn.append(corn[n]+long)
    return np.array(corn)

def euclidean_linspace(start,stop,steps):
    x=np.linspace(start[0],stop[0],steps)
    y=np.linspace(start[1],stop[1],steps)
    z=np.linspace(start[2],stop[2],steps)
    points=[]
    for n in range(len(x)):
        points.append(tuple([x[n],y[n],z[n]]))
    return points

def euclidean_logspace(start,stop,steps):
    x=np.logspace(start[0],stop[0],steps)
    y=np.logspace(start[1],stop[1],steps)
    z=np.linspace(start[2],stop[2],steps)
    points=[]
    for n in range(len(x)):
        points.append(tuple([x[n],y[n],z[n]]))
    return points

def angle_linespace(start,stop,steps):
    angle1=np.arctan2(start[1],start[0])
    angle2=np.arctan2(stop[1],stop[0])
    if angle1<0:
        angle1=(2*np.pi)+angle1

    if angle2<0:
        angle2=(2*np.pi)+angle2

    delta_angle=angle2-angle1

    if abs(delta_angle)>np.pi:
        delta_angle=(2*np.pi-abs(delta_angle))*-1*np.sign(delta_angle)

    angle_step=delta_angle/steps
    return_angles=[]
    return_vectors=[]

    for n in range(steps):
        next_angle=angle1+n*angle_step
        if next_angle>=2*np.pi:
            next_angle=0

        return_angles.append(next_angle)
        return_vectors.append((np.cos(next_angle),np.sin(next_angle),0))
    
    return return_vectors,return_angles

class Weld_Mesh:
    def __init__(self,longx,shortx,x_interval,longy,shorty,y_interval,z_interval,plate_height,slotheight):
        ni, nj, nk = int(x_interval), int(y_interval), int(z_interval)
        sk = plate_height
        self.plate_height=plate_height
        self.slotheight=slotheight
        self.shortx=shortx
        self.shorty=shorty
        self.longx=longx
        self.longy=longy


        xcorn1=make_uneven_array(ni,longx,shortx)
        xcorn = np.repeat(xcorn1, 2)
        xcorn = xcorn[1:-1]
        xcorn = np.tile(xcorn, 4 * nj * nk)

        ycorn1=make_uneven_array(nj,longy,shorty)
        ycorn = np.repeat(ycorn1, 2)
        ycorn = ycorn[1:-1]
        ycorn = np.tile(ycorn, (2 * ni, 2 * nk))
        ycorn = np.transpose(ycorn)
        ycorn = ycorn.flatten()

        zcorn1 = np.arange(0, (nk + 1) * sk, sk)
        zcorn = np.repeat(zcorn1, 2)
        zcorn = zcorn[1:-1]
        zcorn = np.repeat(zcorn, (4 * ni * nj))

        corners = np.stack((xcorn, ycorn, zcorn))
        corners = corners.transpose()
        
        boxes=[]

        for n in range(int((len(xcorn1)-2)/2)):
            dim1=(xcorn1[(n*2)+1], xcorn1[(n*2)+2], ycorn[0], ycorn[-1], zcorn1[0], zcorn1[-1]+slotheight)
            box1=pv.Box(bounds=dim1)
            boxes.append(box1)

        for n in range(int((len(ycorn1)-2)/2)):
            dim1=(xcorn1[0], xcorn1[-1], ycorn1[(n*2)+1], ycorn1[(n*2)+2], zcorn1[0], zcorn1[-1]+slotheight)
            box1=pv.Box(bounds=dim1)
            boxes.append(box1)
        
        if pv._vtk.VTK9:
            dims = np.asarray((ni, nj, nk)) + 1
            grid = pv.ExplicitStructuredGrid(dims, corners)
            grid = grid.compute_connectivity()
            boxes.append(grid)
 
        block = pv.MultiBlock(boxes)
        self.weld_unstruct_grid= block.combine(merge_points=True)
        self.weld_mesh_geo=self.weld_unstruct_grid.extract_geometry()


        desired_points=[]
        bounds=self.weld_unstruct_grid.bounds
        points=self.weld_mesh_geo.points

        for n in range(len(self.weld_unstruct_grid.points)):
            point=points[n]

            if not(point[0]==bounds[0]) and not(point[0]==bounds[1]) and not(point[1]==bounds[2]) and not(point[1]==bounds[3]) \
                and not(point[2]==bounds[4]) and not(point[2]==bounds[5]):
                desired_points.append(tuple(point))
        self.desired_points=desired_points
        # print(desired_points)


class TCP_solution:
    def __init__(self,Weld_Mesh,Include_Joint_Metrics=False):

        self.Include_Joint_Metrics=Include_Joint_Metrics
        
        if Include_Joint_Metrics==True:
            self.IK_SOlVER=Inverse_Kinematics_Solver()

        self.plate_height=Weld_Mesh.plate_height
        self.slotheight=Weld_Mesh.slotheight
        self.shortx=Weld_Mesh.shortx
        self.shorty=Weld_Mesh.shorty
        self.longx=Weld_Mesh.longx
        self.longy=Weld_Mesh.longy

        self.Weld_Mesh_Surface=Weld_Mesh.weld_mesh_geo
        self.Weld_Mesh_Cells=Weld_Mesh.weld_unstruct_grid
        
        self.create_node_dict(Weld_Mesh.desired_points)

        self.desired_points=Weld_Mesh.desired_points
        
        self.Graph = nx.complete_graph(self.node_dict.keys())

        self.compute_edges()

        self.solve_tour()
        
    def create_node_dict(self,point_list):
        node_dict={}
        for n in range(len(point_list)):
            node_dict[n]=tuple(point_list[n])
        self.node_dict= node_dict

    def solve_tour(self):
        tour=approximation.traveling_salesman.traveling_salesman_problem(self.Graph, weight='weight')
        self.tour=tour
        print(tour)
        self.tour_edges=list(zip(tour,tour[1:]))

    def get_higher_resolution_tour(self,plot=False,tour_resolution=None):
        #Think about this function
        if self.Include_Joint_Metrics==True:
            self.IK_SOlVER.ik_solver._solve_type= "Distance"

        if plot==None:
            plot=False
        if tour_resolution==None:
            tour_resolution=100
        
        # print('hi')
        blue = np.array([12 / 256, 238 / 256, 246 / 256, 1.0])
        black = np.array([11 / 256, 11 / 256, 11 / 256, 1.0])
        grey = np.array([189 / 256, 189 / 256, 189 / 256, 1.0])
        yellow = np.array([255 / 256, 247 / 256, 0 / 256, 1.0])
        red = np.array([1.0, 0.0, 0.0, 1.0])
        tour_path=[]
        orientation_vectors=[]
        angles=[]
        
        if plot==True:
            plotter=pv.Plotter()
        
        for n in range(len(self.tour_edges)):
            edge=self.Graph.edges[self.tour_edges[n]]['edge']
            edge.make_smooth_line(Smoothness_Coefficient=50,Interpolation_Resolution=tour_resolution,Weight_Ratio=None)
            edge.make_orientation_vectors()
            
            # if n>0 and self.Include_Joint_Metrics==True:
            #     seed_state=angles[len(angles)-1]
            # elif self.Include_Joint_Metrics==True:
            #     seed_state=[0]*self.IK_SOlVER.ik_solver.number_of_joints

            edge.compute_joint_distances(self.IK_SOlVER,edge.joint_start,edge.joint_end)
            
            if not(edge.PathDirection[0]==self.node_dict[self.tour_edges[n][0]]):
                # print('hello there')
                edge.Path.reverse()
                edge.orientation_vectors.reverse()
                if self.Include_Joint_Metrics==True:
                    edge.angles.reverse()


            tour_path=tour_path+edge.Path
            orientation_vectors=orientation_vectors+edge.orientation_vectors
            if self.Include_Joint_Metrics==True:
                angles=angles+edge.angles

            if plot==True:
                for k in range(len(edge.Path)):
                    orientation_vector=edge.orientation_vectors[k]
                    vector_position=np.array(edge.Path[k])-np.array(orientation_vector)
                    arrow=pv.Arrow(vector_position,np.array(orientation_vector),scale=np.linalg.norm(orientation_vector))
                    plotter.add_mesh(arrow,color=blue)

            
        if plot==True:
            lines= pv.lines_from_points(tour_path)
            plotter.add_mesh(self.Weld_Mesh_Surface, opacity=1.0, color=True)
            plotter.add_mesh(lines,line_width=5,color=black)
            plotter.add_points(np.array(self.desired_points),color=red,point_size=20)
            plotter.show_axes()
            plotter.show()

        self.tcp_points=np.array(tour_path)
        self.tcp_vectors=orientation_vectors
        if self.Include_Joint_Metrics==True:
            # print(np.array(angles))
            # print(angles)
            self.tcp_angles=np.array(angles)
            
    def Post_proccess_path_angles(self):
        
        delta_angles_total=np.array([0]*self.IK_SOlVER.ik_solver.number_of_joints)
        
        for k in range(len(delta_angles_total)):
            for n in range(len(self.tcp_angles[:,k])-1):
                if abs(self.tcp_angles[n,k]-self.tcp_angles[n+1,k])>1*np.pi:
                    self.tcp_angles[n+1,k]=self.tcp_angles[n+1,k]+2*np.pi*np.sign(self.tcp_angles[n,k])

        for k in range(len(delta_angles_total)):
            max=np.max(self.tcp_angles[:,k])
            min=np.min(self.tcp_angles[:,k])
            if max>2*np.pi:
                self.tcp_angles[:,k]=self.tcp_angles[:,k]-np.array([1]*len(self.tcp_angles[:,k]))*(2*np.pi)
            elif min<-2*np.pi:
                self.tcp_angles[:,k]=self.tcp_angles[:,k]+np.array([1]*len(self.tcp_angles[:,k]))*(2*np.pi)
                    
    def compute_edges(self):
        if self.Include_Joint_Metrics==True:
                nx.set_node_attributes(self.Graph,None,"Desired_Point_IK")

        for (u,v) in self.Graph.edges:
            edge=self.compute_edge_line(u,v)
            nx.set_edge_attributes(self.Graph,{(u,v):edge},'edge')
            if self.Include_Joint_Metrics==True:
                nx.set_edge_attributes(self.Graph,{(u,v):edge.Cost_Function},'weight')
            else:
                nx.set_edge_attributes(self.Graph,{(u,v):edge.Path_Distance},'weight')

    def compute_edge_line(self,u,v):
        p1,p2=self.node_dict[u],self.node_dict[v]
        pdist=np.linalg.norm(np.array(p2)-np.array(p1))
        if (pdist==self.longx or pdist==self.longy or pdist==np.sqrt(self.longx**2+self.longy**2)):
            height_scaling=self.plate_height
            length_scaling=(np.sqrt(self.shortx**2+self.shorty**2))/2
            c1,normal1=self.compute_control_point_linear(p1,height_scaling,length_scaling)
            c2,normal2=self.compute_control_point_linear(p2,height_scaling,length_scaling)
            edge=edge_line(np.array(euclidean_linspace(p1,c1,3)+euclidean_linspace(c1,c2,10)+euclidean_linspace(c2,p2,3)),normal1,normal2)
            edge.make_smooth_line(Smoothness_Coefficient=50,Interpolation_Resolution=10,Weight_Ratio=None)

        else:
            height_scaling=self.plate_height+self.slotheight
            length_scaling=(np.sqrt(self.shortx**2+self.shorty**2))/2
            c1,normal1=self.compute_control_point_linear(p1,height_scaling,length_scaling)
            c2,normal2=self.compute_control_point_linear(p2,height_scaling,length_scaling)
            edge=edge_line(np.array(euclidean_linspace(p1,c1,10)+euclidean_linspace(c1,c2,10)+euclidean_linspace(c2,p2,10)),normal1,normal2)
            edge.make_smooth_line(Smoothness_Coefficient=50,Interpolation_Resolution=10,Weight_Ratio=None)
        
        if self.Include_Joint_Metrics==True:
            if self.Graph.nodes[u]["Desired_Point_IK"]==None:  
                self.Graph.nodes[u]["Desired_Point_IK"]=self.IK_SOlVER.get_IK(orientation_vector=normal1,point=c1,
                                                                              bounds_rotation=[1e-3,1e-3,np.inf])
            if self.Graph.nodes[v]["Desired_Point_IK"]==None:
                self.Graph.nodes[v]["Desired_Point_IK"]=self.IK_SOlVER.get_IK(orientation_vector=normal2,point=c2,
                                                                              bounds_rotation=[1e-3,1e-3,np.inf])
            edge.compute_joint_distances(self.IK_SOlVER,initial_IK_state=self.Graph.nodes[u]["Desired_Point_IK"],
                                         final_IK_state=self.Graph.nodes[v]["Desired_Point_IK"])
            # edge.compute_joint_distances(self.IK_SOlVER)

        return edge


    def compute_control_point_linear(self,P1,height_scaling,length_scaling):
        cells=self.Weld_Mesh_Surface.find_cells_along_line(P1,P1)
        avg_points=[]
        tac_normals=np.array([0,0,0])
        for n in range(len(cells)):
            tac_normals=tac_normals+np.array(self.Weld_Mesh_Surface.cell_normals[cells[n]])
        tac_normals[0:2]=(tac_normals[0:2]/np.linalg.norm(tac_normals[0:2]))*length_scaling
        tac_normals[2]=1*height_scaling
        controlpoint=np.array(tac_normals+P1)
        return tuple(controlpoint),tac_normals



class edge_line:
    def __init__(self,control_points,normal1,normal2):
        normal1[2]=0
        normal1=normal1/np.linalg.norm(normal1)
        normal2[2]=0
        normal2=normal2/np.linalg.norm(normal2)
        self.normal1=normal1
        self.normal2=normal2
        self.controlpoints=deepcopy(control_points)
        self.orientation_vectors=None
        # self.make_smooth_line(deepcopy(control_points))
    
    def make_smooth_line(self,Smoothness_Coefficient=None,Interpolation_Resolution=None,Weight_Ratio=None):
        # The Smoothness Coefficient Represents how much the spline is willing the deviat from control points to acheive a smooth line
        # too high will result in breaking through the mesh surface
        # The interpolation Resolution is the number of points you would like in the path array
        # The weight Ratio is how much the Node points are weighted compared to the regular points
        
        if Smoothness_Coefficient==None:
            Smoothness_Coefficient=50
        if Interpolation_Resolution==None:
            Interpolation_Resolution=50
        # if Weight_Ratio==None:
        #     Weight_Ratio=0.01
        self.Interpolation_Resolution=Interpolation_Resolution
        weights=[]
        x=self.controlpoints[:,0]
        y=self.controlpoints[:,1]
        z=self.controlpoints[:,2]
        t=np.linspace(0,len(z)-1,len(z))

        weights=[1]*len(self.controlpoints)
        weights[0]=100
        weights[-1]=100

        # print(self.Interpolation_Resolution)

        splx=scipy.interpolate.make_smoothing_spline(t, x, w=weights, lam=Smoothness_Coefficient)
        sply=scipy.interpolate.make_smoothing_spline(t, y, w=weights, lam=Smoothness_Coefficient)
        splz=scipy.interpolate.make_smoothing_spline(t, z, w=weights, lam=Smoothness_Coefficient)
        
        self.Parametric_Equations=[splx,sply,splz,t]
        #Save the parametric equations so that the derivates can be utilized in the controller algorithm
        #Probably something like this https://docs.scipy.org/doc/scipy/reference/generated/scipy.interpolate.UnivariateSpline.derivatives.html
        t_interpolate=np.linspace(0,len(z)-1,self.Interpolation_Resolution)
        splx_return=splx(t_interpolate)
        sply_return=sply(t_interpolate)
        splz_return=splz(t_interpolate)
        Path_return=[(splx_return[i], sply_return[i], splz_return[i]) for i in range(0, len(t_interpolate))]
        
        Path_Distance=0

        for n in range(len(Path_return)-1):
            Path_Distance+=scipy.spatial.distance.euclidean(Path_return[n],Path_return[n+1])
                
        self.PathDirection=[tuple(self.controlpoints[0]),tuple(self.controlpoints[-1])]

        
        self.Joint_Distance=[]
        
        
        
        self.Path_Distance=Path_Distance
        self.Path=Path_return


    def compute_joint_distances(self,IK_object,initial_IK_state=None,final_IK_state=None):
        #modify this now
        #You definitely made some bugs with allocatings the seed states if there is no solution found

        
        if self.orientation_vectors==None:
            #??????
            self.make_orientation_vectors()
        
        delta_angle_max=0

        angles=[]
        Angle_Distance_Consecutive=[]
        Angle_Distance_Total=np.array([0]*IK_object.ik_solver.number_of_joints)
        Angle_Distance_Cost_Scaled=np.array([0]*IK_object.ik_solver.number_of_joints)
        
        bool=True
        # print('angles at first:')

        angles=[0]*len(self.Path)
        # print(angles)
        # print(len(self.Path))
        # print((len(self.Path)-2)%2)
        
        angles[0]=initial_IK_state
        angles[-1]=final_IK_state
        # print(angles)

        self.joint_start=initial_IK_state
        self.joint_end=final_IK_state

        for n in range(int((len(self.Path)-2)/2)+((len(self.Path)-2)%2)):
            # print('start index:')
            start_index=n+1
            # print(start_index)
            end_index=len(self.Path)-n-2
            # print('end index:')
            # print(end_index)
            
            angle_start=IK_object.get_IK(point=self.Path[start_index],orientation_vector=self.orientation_vectors[start_index],
                                         seed_state=initial_IK_state,bounds_rotation=[1e-3,1e-3,np.inf])
            
            angle_end=IK_object.get_IK(point=self.Path[end_index],orientation_vector=self.orientation_vectors[end_index],
                                       seed_state=final_IK_state,bounds_rotation=[1e-3,1e-3,np.inf])
            
            
            # print('angle_start found:')
            # print(angle_start)

            # print('angle_end found:')
            # print(angle_end)

            if angle_end==None:
                angle_start=IK_object.get_IK(point=self.Path[start_index],orientation_vector=self.orientation_vectors[start_index],
                                             seed_state=initial_IK_state,bounds_rotation=[1e-2,1e-2,np.inf])
            if angle_start==None:
                angle_end=IK_object.get_IK(point=self.Path[end_index],orientation_vector=self.orientation_vectors[end_index],
                                           seed_state=final_IK_state,bounds_rotation=[1e-2,1e-2,np.inf])

            if angle_end==None:
                angles[start_index]=[np.inf]*6
            if angle_start==None:
                angles[start_index]=[np.inf]*6
            
            if start_index==end_index:
                print('hi')
                distance1=np.sum(abs(np.array(final_IK_state)-np.array(angle_start))+abs(np.array(initial_IK_state)-np.array(angle_start)))

                distance2=np.sum(abs(np.array(final_IK_state)-np.array(angle_end))+abs(np.array(initial_IK_state)-np.array(angle_end)))

                if distance1>distance2:
                    angles[end_index]=angle_end
                else:
                    angles[start_index]=angle_start     
            else:
                angles[start_index]=angle_start
                angles[end_index]=angle_end
            
            
            initial_IK_state=angle_start
            final_IK_state=angle_end

            # print('intial IK state:')
            # print(initial_IK_state)
            
            # print('final IK state:')
            # print(final_IK_state)

            # print('angles after step:')
            # print(n)
            # print(angles)
            # input('enter to continue:')

        #you could probably do this next loop partially above- but too hard
        for n in range(len(angles)-1):
            
            # print(angle)

            for k in range(len(angles[n])):
                angle_flipped=angles[n+1][k]-np.pi*2*np.sign(angles[n+1][k])

                if (abs(angles[n][k]-angles[n+1][k])>abs(angles[n][k]-angle_flipped)) and abs(angle_flipped)<=2*np.pi:
                    # print('yes')
                    angles[n+1][k]=angle_flipped
            
            delta_angles=np.array(angles[n+1])-np.array(angles[n])

            Angle_Distance_Consecutive.append(abs(delta_angles))
            Angle_Distance_Total=Angle_Distance_Total+np.array(abs(delta_angles))
            Angle_Distance_Cost_Scaled=Angle_Distance_Cost_Scaled+(np.array(abs(delta_angles))/np.pi*2)

        self.angles=angles
        self.Angle_Distance_Consecutive=Angle_Distance_Consecutive
        self.Angle_Distance_Total=Angle_Distance_Total
        self.Cost_Function=self.Path_Distance*0+1*np.dot(Angle_Distance_Cost_Scaled,np.array([1,1,1,1,1,0]))
        

    def make_orientation_vectors(self):
        orientation_vectors,thetas=angle_linespace(tuple(self.normal1*-1),tuple(self.normal2*-1),self.Interpolation_Resolution)
        self.orientation_vectors=orientation_vectors

class Inverse_Kinematics_Solver:
    
    def __init__(self):
        moveit_commander.roscpp_initialize(sys.argv)
        rospy.init_node('move_group_node',
                anonymous=True)
        self.aligned_tool0_vector=np.array([0,1,0])
        group_name = "manipulator"
        self.move_group = moveit_commander.MoveGroupCommander(group_name)

        self.ik_solver = IK("base_link",
                "tool0",solve_type="Distance")
        
    def get_rotation_from_vectors(self,v1,v2):
        k=np.cross(v1,v2)
        k=k/np.linalg.norm(k)
        theta=np.arccos(np.dot(v1,v2)/(np.linalg.norm(v1)*np.linalg.norm(v2)))
        r=scipy.spatial.transform.Rotation.from_rotvec((theta*np.array(k)))
        p=scipy.spatial.transform.Rotation.from_rotvec((np.pi*np.array([0,1,0])))
        r=p*r
        return r
    
    def get_IK(self,point,orientation_vector,seed_state=None,bounds_rotation=None):
        if seed_state==None:
            seed_state=[0,-np.pi/2,np.pi/2,-np.pi/2,-np.pi/2,np.pi/2]

        x=point[0]/100+0.25
        y=point[1]/100+0.25
        z=point[2]/100
        r=self.get_rotation_from_vectors(self.aligned_tool0_vector,orientation_vector)
        quat=r.as_quat()
        if bounds_rotation==None:
            sol = (self.ik_solver.get_ik(seed_state,
                                    x, y, z,
                                    quat[0], quat[1], quat[2], quat[3]))
        else:
            sol = (self.ik_solver.get_ik(seed_state,
                                    x, y, z,
                                    quat[0], quat[1], quat[2], quat[3],
                                    brx=bounds_rotation[0], bry=bounds_rotation[1], brz=bounds_rotation[2]))
        
        if not(sol==None):
            angles=list(sol)
        else:
            angles=None

        return angles

        
        
    
    

    


