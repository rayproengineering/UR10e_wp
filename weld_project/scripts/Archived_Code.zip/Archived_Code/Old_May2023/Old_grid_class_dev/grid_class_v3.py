#!/usr/bin/env python3

import pyvista as pv
import  numpy as np
import networkx as nx
from networkx.algorithms import approximation
import scipy
from scipy.interpolate import make_smoothing_spline
from copy import deepcopy
import copy

import rospy
from trac_ik_python.trac_ik import IK
import moveit_commander
import geometry_msgs.msg as geometry_msgs
import sys
import moveit_msgs.msg
import shape_msgs
from std_msgs.msg import String
from moveit_commander.conversions import pose_to_list
import moveit.core.collision_detection

import trajectory_msgs.msg
import std_msgs.msg

import matplotlib as mpl
import matplotlib.pyplot as plt
from moveit_msgs.msg import RobotTrajectory
import actionlib
import actionlib_msgs

JOINT_NAMES = [
    "shoulder_pan_joint",
    "shoulder_lift_joint",
    "elbow_joint",
    "wrist_1_joint",
    "wrist_2_joint",
    "wrist_3_joint",
]

def make_uneven_array(interval,long,short):
    corn=[0]
    for n in range(int(interval)):
        if ((n+1)%2)==0:
            corn.append(corn[n]+short)
        else:
            corn.append(corn[n]+long)
    return np.array(corn)

def euclidean_linspace(start,stop,steps):
    x=np.linspace(start[0],stop[0],steps)
    y=np.linspace(start[1],stop[1],steps)
    z=np.linspace(start[2],stop[2],steps)
    points=[]
    for n in range(len(x)):
        points.append(tuple([x[n],y[n],z[n]]))
    return points

def euclidean_logspace(start,stop,steps):
    x=np.logspace(start[0],stop[0],steps)
    y=np.logspace(start[1],stop[1],steps)
    z=np.linspace(start[2],stop[2],steps)
    points=[]
    for n in range(len(x)):
        points.append(tuple([x[n],y[n],z[n]]))
    return points

def angle_linespace(start,stop,steps):
    angle1=np.arctan2(start[1],start[0])
    angle2=np.arctan2(stop[1],stop[0])

    if angle1<0:
        angle1=(2*np.pi)+angle1

    if angle2<0:
        angle2=(2*np.pi)+angle2

    delta_angle=angle2-angle1

    if angle1%(np.pi/2)==0:
        print(angle1)
    if angle2%(np.pi/2)==0:
        print(angle2)

    if abs(delta_angle)>np.pi:
        delta_angle=(2*np.pi-abs(delta_angle))*-1*np.sign(delta_angle)

    angle_step=delta_angle/steps
    return_angles=[]
    return_vectors=[]

    for n in range(steps):
        next_angle=angle1+n*angle_step
        return_angles.append(next_angle)
        return_vectors.append((np.cos(next_angle),np.sin(next_angle),0))
    
    return return_vectors,return_angles


class Weld_Mesh:
    def __init__(self,longx,shortx,x_interval,longy,shorty,y_interval,z_interval,plate_height,slotheight):
        ni, nj, nk = int(x_interval), int(y_interval), int(z_interval)
        sk = plate_height
        self.plate_height=plate_height
        self.slotheight=slotheight
        self.shortx=shortx
        self.shorty=shorty
        self.longx=longx
        self.longy=longy


        xcorn1=make_uneven_array(ni,longx,shortx)
        xcorn = np.repeat(xcorn1, 2)
        xcorn = xcorn[1:-1]
        xcorn = np.tile(xcorn, 4 * nj * nk)

        ycorn1=make_uneven_array(nj,longy,shorty)
        ycorn = np.repeat(ycorn1, 2)
        ycorn = ycorn[1:-1]
        ycorn = np.tile(ycorn, (2 * ni, 2 * nk))
        ycorn = np.transpose(ycorn)
        ycorn = ycorn.flatten()

        zcorn1 = np.arange(0, (nk + 1) * sk, sk)
        zcorn = np.repeat(zcorn1, 2)
        zcorn = zcorn[1:-1]
        zcorn = np.repeat(zcorn, (4 * ni * nj))

        corners = np.stack((xcorn, ycorn, zcorn))
        corners = corners.transpose()
        
        boxes=[]

        for n in range(int((len(xcorn1)-2)/2)):
            dim1=(xcorn1[(n*2)+1], xcorn1[(n*2)+2], ycorn[0], ycorn[-1], zcorn1[0], zcorn1[-1]+slotheight)
            box1=pv.Box(bounds=dim1)
            boxes.append(box1)

        for n in range(int((len(ycorn1)-2)/2)):
            dim1=(xcorn1[0], xcorn1[-1], ycorn1[(n*2)+1], ycorn1[(n*2)+2], zcorn1[0], zcorn1[-1]+slotheight)
            box1=pv.Box(bounds=dim1)
            boxes.append(box1)
        
        if pv._vtk.VTK9:
            dims = np.asarray((ni, nj, nk)) + 1
            grid = pv.ExplicitStructuredGrid(dims, corners)
            grid = grid.compute_connectivity()
            boxes.append(grid)
 
        block = pv.MultiBlock(boxes)
        self.weld_unstruct_grid= block.combine(merge_points=True)
        self.weld_mesh_geo=self.weld_unstruct_grid.extract_geometry()

        desired_points=[]
        bounds=self.weld_unstruct_grid.bounds
        points=self.weld_mesh_geo.points

        for n in range(len(self.weld_unstruct_grid.points)):
            point=points[n]

            if not(point[0]==bounds[0]) and not(point[0]==bounds[1]) and not(point[1]==bounds[2]) and not(point[1]==bounds[3]) \
                and not(point[2]==bounds[4]) and not(point[2]==bounds[5]):
                desired_points.append(tuple(point))
        self.desired_points=desired_points


class TSP_solution:
    def __init__(self,Weld_Mesh,Include_Joint_Metrics=False):
        self.Include_Joint_Metrics=Include_Joint_Metrics
        
        if Include_Joint_Metrics==True:
            self.IK_SOLVER=Inverse_Kinematics_Solver()

        self.control_distance=0.5
    
        self.plate_height=Weld_Mesh.plate_height
        self.slotheight=Weld_Mesh.slotheight
        self.shortx=Weld_Mesh.shortx
        self.shorty=Weld_Mesh.shorty
        self.longx=Weld_Mesh.longx
        self.longy=Weld_Mesh.longy
        self.Weld_Mesh_Surface=Weld_Mesh.weld_mesh_geo
        self.Weld_Mesh_Cells=Weld_Mesh.weld_unstruct_grid
        self.create_node_dict(Weld_Mesh.desired_points)
        self.desired_points=Weld_Mesh.desired_points
        self.Graph = nx.complete_graph(self.node_dict.keys())
        self.get_geometric_type()
        self.lock_geometric_type()
        self.compute_points_IK()
        self.compute_edges()
        self.solve_tour()
        # self.closest_point()
        
    def create_node_dict(self,point_list):
        node_dict={}
        for n in range(len(point_list)):
            node_dict[n]=tuple(point_list[n])
        self.node_dict= node_dict

    def solve_tour(self):
        tour=approximation.traveling_salesman.traveling_salesman_problem(self.Graph, weight='weight')
        self.tour=tour
        print(tour)
        self.tour_edges=list(zip(tour,tour[1:]))

    def get_higher_resolution_tour(self,plot=False,tour_resolution=None):
        #Think about this function
        if self.Include_Joint_Metrics==True:
            self.IK_SOLVER.IK_SOLVER._solve_type= "Distance"

        if plot==None:
            plot=False

        if tour_resolution==None:
            tour_resolution=50
            
        self.tour_resolution=tour_resolution
 
        blue = np.array([12 / 256, 238 / 256, 246 / 256, 1.0])
        black = np.array([11 / 256, 11 / 256, 11 / 256, 1.0])
        grey = np.array([189 / 256, 189 / 256, 189 / 256, 1.0])
        yellow = np.array([255 / 256, 247 / 256, 0 / 256, 1.0])
        red = np.array([1.0, 0.0, 0.0, 1.0])
        
        tour_path=[]
        orientation_vectors=[]
        angles=[]
        
        if plot==True:
            plotter=pv.Plotter()
        
        for n in range(len(self.tour_edges)):

            edge=self.Graph.edges[self.tour_edges[n]]['edge']
            edge.make_smooth_line(Smoothness_Coefficient=10,Interpolation_Resolution=tour_resolution,Weight_Ratio=None)
            edge.make_orientation_vectors()

            # u=self.tour_edges[n]
            # if n==len(self.tour_edges)-1:
            #     v=self.tour_edges[0]
            # else:
            #     v=self.tour_edges[n+1]
            u=self.tour_edges[n][0]
            v=self.tour_edges[n][1]
            print(u)
            print(v)

            edge.compute_joint_distances(self.IK_SOLVER,initial_IK_state=self.Graph.nodes[u]["Point_IK"],
                                         final_IK_state=self.Graph.nodes[v]["Point_IK"])
            
            if not(edge.PathDirection[0]==self.node_dict[self.tour_edges[n][0]]):
                edge.Path.reverse()
                edge.orientation_vectors.reverse()
                if self.Include_Joint_Metrics==True:
                    edge.angles.reverse()

            tour_path=tour_path+edge.Path

            orientation_vectors=orientation_vectors+edge.orientation_vectors

            if self.Include_Joint_Metrics==True:
                angles=angles+edge.angles

            if plot==True:
                for k in range(len(edge.Path)):
                    orientation_vector=edge.orientation_vectors[k]
                    vector_position=np.array(edge.Path[k])-np.array(orientation_vector)
                    arrow=pv.Arrow(vector_position,np.array(orientation_vector),scale=np.linalg.norm(orientation_vector))
                    plotter.add_mesh(arrow,color=blue)
       
        if plot==True:
            lines= pv.lines_from_points(tour_path)
            plotter.add_mesh(self.Weld_Mesh_Surface, opacity=1.0, color=True)
            plotter.add_mesh(lines,line_width=5,color=black)
            plotter.add_points(np.array(self.desired_points),color=red,point_size=20)
            # plotter.add_points(np.array(tour_path),color=blue)
            plotter.show_axes()
            plotter.show()

        self.TSP_points=np.array(tour_path)
        self.TSP_vectors=orientation_vectors
        if self.Include_Joint_Metrics==True:
            self.TSP_angles=np.array(angles)
            
    
    def Post_proccess_path_angles(self):
        #add storing in each edge.....
        #can I combine this functionality in the other definition.....

        delta_angles_total=np.array([0]*self.IK_SOLVER.IK_SOLVER.number_of_joints)
        
        for k in range(len(delta_angles_total)):
            for n in range(len(self.TSP_angles[:,k])-1):
                if abs(self.TSP_angles[n,k]-self.TSP_angles[n+1,k])>1*np.pi:
                    self.TSP_angles[n+1,k]=self.TSP_angles[n+1,k]+2*np.pi*np.sign(self.TSP_angles[n,k])

        for k in range(len(delta_angles_total)):
            max=np.max(self.TSP_angles[:,k])
            min=np.min(self.TSP_angles[:,k])
            if max>2*np.pi:
                self.TSP_angles[:,k]=self.TSP_angles[:,k]-np.array([1]*len(self.TSP_angles[:,k]))*(2*np.pi)
            elif min<-2*np.pi:
                self.TSP_angles[:,k]=self.TSP_angles[:,k]+np.array([1]*len(self.TSP_angles[:,k]))*(2*np.pi)

        for n in range(len(self.tour_edges)):
            edge=self.Graph.edges[self.tour_edges[n]]['edge']
            edge.angles=self.TSP_angles[(n*(self.tour_resolution)):(((n+1)*(self.tour_resolution))-1)]

        
    def Send_to_robot(self):
        joint_goal=self.IK_SOLVER.move_group.get_current_joint_values()
        joint_goal[3]=self.TSP_angles[0,3]
        joint_goal[4]=self.TSP_angles[0,4]
        joint_goal[5]=self.TSP_angles[0,5]
        print(joint_goal)
        self.IK_SOLVER.move_group.go(np.array(joint_goal),wait=True)

        for n in range(len(self.tour_edges)):
            edge=self.Graph.edges[self.tour_edges[n]]['edge']
            # print(edge.angles[0])
            input("Press Enter To Advance To The Next TAC Point:")
            self.IK_SOLVER.send_joint_path_to_moveit(edge.angles)
    

    def get_geometric_type(self):
        self.IK_SOLVER.IK_SOLVER._solve_type= "Speed"
        
        nx.set_node_attributes(self.Graph,None,"Normals")
        nx.set_node_attributes(self.Graph,None,"Control_Points")
        nx.set_node_attributes(self.Graph,None,"Point_IK")

        for u in self.Graph.nodes:
            self.Graph.nodes[u]["Normals"]=self.compute_normal(self.node_dict[u])
            self.Graph.nodes[u]["Control_Points"]=self.compute_control_points(self.Graph.nodes[u]["Normals"],self.node_dict[u])

        origin=np.array([[0,0,0]])
        x=scipy.spatial.distance.cdist(origin,np.array(list(self.node_dict.values())),'euclidean')
        seed_state=list(self.IK_SOLVER.move_group.get_current_joint_values())
        
        farthest_point_index=np.argmax(x)
        closest_point_index=np.argmin(x)


        seed_state=list(self.IK_SOLVER.move_group.get_current_joint_values())

        closest_points_angles=self.IK_SOLVER.get_IK(self.node_dict[closest_point_index],list([self.Graph.nodes[closest_point_index]["Normals"][0],self.Graph.nodes[closest_point_index]["Normals"][1],0]),seed_state=seed_state)
        farthest_points_angles=self.IK_SOLVER.get_IK(self.node_dict[farthest_point_index],list([self.Graph.nodes[farthest_point_index]["Normals"][0],self.Graph.nodes[farthest_point_index]["Normals"][1],0]),seed_state=seed_state)
        close_config=self.configuration_type(closest_points_angles)
        long_config=self.configuration_type(farthest_points_angles)
        
        
        if long_config==close_config:
            #hopefully they match
            print('Configuration Types Match')
            self.configuration=close_config
            

        else:
            print('Configuration Types DO Not Match Revalutating')
            closest_points_angles=self.IK_SOLVER.get_IK(self.node_dict[closest_point_index],list([self.Graph.nodes[closest_point_index]["Normals"][0],self.Graph.nodes[closest_point_index]["Normals"][1],0]),seed_state=farthest_points_angles)
            close_config=self.configuration_type(closest_points_angles)
            if long_config==close_config:
                #try to get long config
                print('Configuration Types Match')
                self.configuration=close_config
                
            else:
                print('Configuration Types DO Not Match Revalutating')
                closest_points_angles=self.IK_SOLVER.get_IK(self.node_dict[closest_point_index],list([self.Graph.nodes[closest_point_index]["Normals"][0],self.Graph.nodes[closest_point_index]["Normals"][1],0]),seed_state=seed_state)
                farthest_points_angles=self.IK_SOLVER.get_IK(self.node_dict[farthest_point_index],list([self.Graph.nodes[farthest_point_index]["Normals"][0],self.Graph.nodes[farthest_point_index]["Normals"][1],0]),seed_state=closest_points_angles)
                close_config=self.configuration_type(closest_points_angles)
                long_config=self.configuration_type(farthest_points_angles)
                if long_config==close_config:
                    #this is short config
                    print('Configuration Types Match')
                    self.configuration=close_config
                    
                else:
                    print('Can not match configuration types')

        self.Graph.nodes[farthest_point_index]["Point_IK"]=farthest_points_angles
        self.Graph.nodes[closest_point_index]["Point_IK"]=closest_points_angles
        self.closest_point_index=closest_point_index

    def configuration_type(self,angles):
        if 0<angles[3]<np.pi or -np.pi>angles[3]>-2*np.pi:
            #configuration short
            return 0
        elif np.pi<angles[3]<2*np.pi or 0>angles[3]>-np.pi:
            #configuration long
            return 1
        else:
            #configuration indeterminante
            return 2
        
    def lock_geometric_type(self):
        #set joint limits in here for both the IK solver and move it
        # joint_values=self.IK_SOLVER.move_group.get_current_joint_values()
        if self.configuration==0:
            #short config
            lower_bounds=[-2*np.pi,-np.pi,-np.pi,0,-2*np.pi,2*np.pi]
            upper_bounds=[2*np.pi,0,np.pi,np.pi,2*np.pi,2*np.pi]


        elif self.configuration==1:
            #long config
            lower_bounds=[-2*np.pi,-np.pi,-np.pi,-np.pi,-2*np.pi,-2*np.pi]
            upper_bounds=[2*np.pi,0,np.pi,0,2*np.pi,2*np.pi]
        else:
            print('Roman Has not programmed this')
        self.IK_SOLVER.IK_SOLVER.set_joint_limits(lower_bounds, upper_bounds)
        # self.IK_SOLVER.move_group


    def closest_point(self):
        pose=self.IK_SOLVER.move_group.get_current_pose()
        point=[pose.pose.position.x,pose.pose.position.y,pose.pose.position.z]
        
        self.KDTREE=scipy.spatial.KDTree(np.array(self.desired_points)/100)
        d,index=self.KDTREE.query(point)
        print(d)
        print(index)
        
        
        point_reorientate=np.array(list(self.node_dict[index]))+np.array(list([-self.Graph.nodes[index]["Normals"][0],-self.Graph.nodes[index]["Normals"][1],0]))*(np.sqrt(self.longx**2+self.longy**2)/2)
        r=self.IK_SOLVER.get_rotation_from_vectors(self.IK_SOLVER.aligned_tool0_vector,list([-self.Graph.nodes[index]["Normals"][0],-self.Graph.nodes[index]["Normals"][1],0]))
        quat=r.as_quat()
        pose_goal = geometry_msgs.Pose()
        pose_goal.orientation.x = quat[0]
        pose_goal.orientation.y = quat[1]
        pose_goal.orientation.z = quat[2]
        pose_goal.orientation.w = quat[3]
        pose_goal.position.x = (point_reorientate[0]/100)+0.25
        pose_goal.position.y = (point_reorientate[1]/100)+0.30
        pose_goal.position.z = (point_reorientate[2]/100)+0.15

        
        joint_goal=self.IK_SOLVER.move_group.get_current_joint_values()
        print(self.configuration)
        if self.configuration==0:
            #short
            joint_goal[5]=self.Graph.nodes[index]["Point_IK"][5]
            joint_goal[4]=self.Graph.nodes[index]["Point_IK"][4]
            joint_goal[5]=0
            joint_goal[4]=np.pi/2
            joint_goal[3]=np.pi/2
        elif self.configuration==1:
            #long
            joint_goal[5]=self.Graph.nodes[index]["Point_IK"][5]
            joint_goal[4]=self.Graph.nodes[index]["Point_IK"][4]
            joint_goal[5]=0
            joint_goal[4]=-np.pi/2
            joint_goal[3]=-np.pi/2
        else:
            
            print('Roman Has not programmed this')
    
        self.IK_SOLVER.move_group.go(joint_goal,wait=True)
        self.IK_SOLVER.move_group.set_pose_target(pose_goal)
        self.IK_SOLVER.move_group.go(pose_goal,wait=True)
        self.IK_SOLVER.move_group.clear_pose_targets()

    def compute_points_IK(self):
        self.IK_SOLVER.IK_SOLVER._solve_type= "Distance"
        seed_state=list(self.IK_SOLVER.move_group.get_current_joint_values())
        closet_points_angles=self.IK_SOLVER.get_IK(self.node_dict[self.closest_point_index],list([self.Graph.nodes[self.closest_point_index]["Normals"][0],self.Graph.nodes[self.closest_point_index]["Normals"][1],0]))
        
        self.Graph.nodes[self.closest_point_index]["Point_IK"]=closet_points_angles
        point_angles=[]
        for u in self.Graph.nodes:
            if type(self.Graph.nodes[u]["Point_IK"])==type(None):
                joint_IK=self.IK_SOLVER.get_IK(self.node_dict[u],list([self.Graph.nodes[u]["Normals"][0],self.Graph.nodes[u]["Normals"][1],0]))
                if type(self.Graph.nodes[u]["Point_IK"])==None:
                    print('Warning no joint angles for a point')
                self.Graph.nodes[u]["Point_IK"]=joint_IK
                point_angles.append(joint_IK)
        self.point_angles=np.array(point_angles)
       

    def compute_edges(self):
        for (u,v) in self.Graph.edges:
            edge=self.compute_edge_line(u,v)
            nx.set_edge_attributes(self.Graph,{(u,v):edge},'edge')
            if self.Include_Joint_Metrics==True:
                nx.set_edge_attributes(self.Graph,{(u,v):edge.Cost_Function},'weight')
            else:
                nx.set_edge_attributes(self.Graph,{(u,v):edge.Path_Distance},'weight')

    def compute_edge_line(self,u,v):
        normal1=self.Graph.nodes[u]["Normals"]
        normal2=self.Graph.nodes[v]["Normals"]
        controlpoints1=self.Graph.nodes[u]["Control_Points"]
        controlpoints2=self.Graph.nodes[v]["Control_Points"]
        
        p1,p2=self.node_dict[u],self.node_dict[v]

        pdist=np.linalg.norm(np.array(p2)-np.array(p1))
            
        if not(self.control_distance==0):
            p1=tuple(np.array(p1)+(np.array(normal1)/np.linalg.norm(normal1))*self.control_distance)
            p2=tuple(np.array(p2)+(np.array(normal2)/np.linalg.norm(normal2))*self.control_distance)
        
        if (pdist==self.longx or pdist==self.longy or pdist==np.sqrt(self.longx**2+self.longy**2)):
            #SHORT
            edge=edge_line(np.array(euclidean_linspace(p1,controlpoints1[0],5)+euclidean_linspace(controlpoints1[0],controlpoints2[0],10)[1:-1]+euclidean_linspace(controlpoints2[0],p2,5)),deepcopy(normal1),deepcopy(normal2))
            edge.make_smooth_line(Smoothness_Coefficient=25,Interpolation_Resolution=20,Weight_Ratio=None)
            edge.Path_order(self.node_dict[u],self.node_dict[v])

        else:
            #LONG
            edge=edge_line(np.array(euclidean_linspace(p1,controlpoints1[1],5)+euclidean_linspace(controlpoints1[1],controlpoints2[1],10)[1:-1]+euclidean_linspace(controlpoints2[1],p2,5)),deepcopy(normal1),deepcopy(normal2))
            edge.make_smooth_line(Smoothness_Coefficient=25,Interpolation_Resolution=20,Weight_Ratio=None)
            edge.Path_order(self.node_dict[u],self.node_dict[v])
        
        if self.Include_Joint_Metrics==True:
            edge.compute_joint_distances(self.IK_SOLVER,initial_IK_state=self.Graph.nodes[u]["Point_IK"],
                                         final_IK_state=self.Graph.nodes[v]["Point_IK"])

        return edge
    
    def compute_normal(self,P1):
        cells=self.Weld_Mesh_Surface.find_cells_along_line(P1,P1)
        avg_points=[]
        tac_normals=np.array([0,0,0])
        for n in range(len(cells)):
            tac_normals=tac_normals+np.array(self.Weld_Mesh_Surface.cell_normals[cells[n]])
        tac_normals[0:2]=(tac_normals[0:2]/np.linalg.norm(tac_normals[0:2]))
        tac_normals[2]=1
        return (tac_normals)
    
    
    def compute_control_points(self,normal,P1):
        self.height_scaling_short=self.plate_height
        self.height_scaling_long=self.plate_height+self.slotheight+1
        self.length_scaling=(np.sqrt(self.shortx**2+self.shorty**2))/2
        controlpoint_long=np.array([normal[0]*self.length_scaling,normal[1]*self.length_scaling,normal[2]*self.height_scaling_long])+np.array(P1)
        controlpoint_short=np.array([normal[0]*self.length_scaling,normal[1]*self.length_scaling,normal[2]*self.height_scaling_short])+np.array(P1)
        controlpoints=[tuple(controlpoint_short),tuple(controlpoint_long)]
        return controlpoints
        
class edge_line:
    def __init__(self,control_points,normal1,normal2):
        normal1[2]=0
        normal1=normal1/np.linalg.norm(normal1)
        normal2[2]=0
        normal2=normal2/np.linalg.norm(normal2)
        self.normal1=normal1
        self.normal2=normal2
        if abs(normal1[0]==1) or abs(normal1[1]==1):
            print(normal1)
        if abs(normal2[0]==1) or abs(normal2[1]==1):
            print(normal2)
        self.controlpoints=deepcopy(control_points)
        self.orientation_vectors=None

    def Path_order(self,desired_start,desired_end):
        self.PathDirection=[tuple(desired_start),tuple(desired_end)]

    
    def make_smooth_line(self,Smoothness_Coefficient=None,Interpolation_Resolution=None,Weight_Ratio=None):
        # The Smoothness Coefficient Represents how much the spline is willing the deviat from control points to acheive a smooth line
        # too high will result in breaking through the mesh surface
        # The interpolation Resolution is the number of points you would like in the path array
        # The weight Ratio is how much the Node points are weighted compared to the regular points
        
        if Smoothness_Coefficient==None:
            Smoothness_Coefficient=50
        if Interpolation_Resolution==None:
            Interpolation_Resolution=50
        # if Weight_Ratio==None:
        #     Weight_Ratio=0.01
        self.Interpolation_Resolution=Interpolation_Resolution
        weights=[]
        x=self.controlpoints[:,0]
        y=self.controlpoints[:,1]
        z=self.controlpoints[:,2]
        t=np.linspace(0,len(z)-1,len(z))

        weights=[1]*len(self.controlpoints)
        weights[0]=100
        weights[-1]=100

        splx=scipy.interpolate.make_smoothing_spline(t, x, w=weights, lam=Smoothness_Coefficient)
        sply=scipy.interpolate.make_smoothing_spline(t, y, w=weights, lam=Smoothness_Coefficient)
        splz=scipy.interpolate.make_smoothing_spline(t, z, w=weights, lam=Smoothness_Coefficient)
        
        self.Parametric_Equations=[splx,sply,splz,t]
        #Save the parametric equations so that the derivates can be utilized in the controller algorithm
        #Probably something like this https://docs.scipy.org/doc/scipy/reference/generated/scipy.interpolate.UnivariateSpline.derivatives.html
        t_interpolate=np.linspace(0,len(z)-1,self.Interpolation_Resolution)
        splx_return=splx(t_interpolate)
        sply_return=sply(t_interpolate)
        splz_return=splz(t_interpolate)
        Path_return=[(splx_return[i], sply_return[i], splz_return[i]) for i in range(0, len(t_interpolate))]
        
        Path_Distance=0

        for n in range(len(Path_return)-1):
            Path_Distance+=scipy.spatial.distance.euclidean(Path_return[n],Path_return[n+1])
                
        
        self.Joint_Distance=[]
        self.Path_Distance=Path_Distance
        self.Path=Path_return


    def compute_joint_distances(self,IK_object,initial_IK_state=None,final_IK_state=None):
        #modify this now
        #You definitely made some bugs with allocatings the seed states if there is no solution found

        if self.orientation_vectors==None:
            self.make_orientation_vectors()
        
        delta_angle_max=0

        angles=[]        
        angles=[0]*len(self.Path)
        angles[0]=initial_IK_state
        angles[-1]=final_IK_state
        
        self.joint_start=initial_IK_state
        self.joint_end=final_IK_state

        for n in range(int((len(self.Path)-2)/2)+((len(self.Path)-2)%2)):
            start_index=n+1
            end_index=len(self.Path)-n-2
            
            angle_start=IK_object.get_IK(point=self.Path[start_index],orientation_vector=self.orientation_vectors[start_index],
                                         seed_state=initial_IK_state)
            
            angle_end=IK_object.get_IK(point=self.Path[end_index],orientation_vector=self.orientation_vectors[end_index],
                                       seed_state=final_IK_state)
            
            if start_index==end_index:
                if angle_start==angle_end:
                    angles[end_index]=angle_end
                else:
                    distance1=np.sum(abs(np.array(final_IK_state)-np.array(angle_start))+abs(np.array(initial_IK_state)-np.array(angle_start)))
                    distance2=np.sum(abs(np.array(final_IK_state)-np.array(angle_end))+abs(np.array(initial_IK_state)-np.array(angle_end)))

                    if distance1>distance2:
                        angles[end_index]=angle_end
                    else:
                        angles[start_index]=angle_start     
            else:
                angles[start_index]=angle_start
                angles[end_index]=angle_end
            
            if angles[start_index]==None:
                angles[start_index]=[np.inf]*6
            
            if angles[end_index]==None:
                angles[end_index]=[np.inf]*6
            
            initial_IK_state=angle_start
            final_IK_state=angle_end
        New_Angle_Cost_Function=0
        for n in range(len(angles)-1):
            #you can probably do this above......
            for k in range(len(angles[n])):
                angle_flipped=angles[n+1][k]-np.pi*2*np.sign(angles[n+1][k])

                if (abs(angles[n][k]-angles[n+1][k])>abs(angles[n][k]-angle_flipped)) and abs(angle_flipped)<=2*np.pi:
                    angles[n+1][k]=angle_flipped
            
            delta_angles=np.array(angles[n+1])-np.array(angles[n])
            New_Angle_Cost_Function=New_Angle_Cost_Function+np.sqrt(np.dot(delta_angles,delta_angles))  

        self.angles=angles
        self.Cost_Function=New_Angle_Cost_Function
        
    def make_orientation_vectors(self):
        orientation_vectors,thetas=angle_linespace(tuple(self.normal1*-1),tuple(self.normal2*-1),self.Interpolation_Resolution)
        self.orientation_vectors=orientation_vectors

class Inverse_Kinematics_Solver:
    def __init__(self):
        moveit_commander.roscpp_initialize(sys.argv)
        rospy.init_node('move_group_node',
                anonymous=False)
        self.robot = moveit_commander.RobotCommander()
        self.scene = moveit_commander.PlanningSceneInterface()
        
        pose=geometry_msgs.PoseStamped()
        pose.pose.position.x=0.25
        pose.pose.position.y=0.30
        pose.pose.position.z=0
        identity=np.eye(3)
        r=scipy.spatial.transform.Rotation.from_matrix(identity)
        quat=r.as_quat()
        header=std_msgs.msg.Header()
        header.frame_id="world"
        header.seq=int(1)

        header.stamp.secs=rospy.Time.now().secs
        header.stamp.nsecs=rospy.Time.now().nsecs
        pose.pose.orientation.x=quat[0]
        pose.pose.orientation.y=quat[1]
        pose.pose.orientation.z=quat[2]
        pose.pose.orientation.w=quat[3]

        pose.header=header

        
        self.scene.add_mesh(name='weld_mesh', pose=pose, filename='Weld_Mesh_V1.stl', size=((1/100), (1/100), (1/100)))
        x=self.scene.get_objects()
        self.scene.add_object(x['weld_mesh'])
        moveit_commander.ApplyPlanningSceneRequest(x['weld_mesh'])
       


        self.aligned_tool0_vector=np.array([0,1,0])
        
        
        
        group_name = "manipulator"
        move_group=moveit_commander.MoveGroupCommander(group_name)
        self.move_group = move_group
        self.IK_SOLVER = IK("base_link",
                "tool0",solve_type="Speed")
        
        
    def get_rotation_from_vectors(self,v1,v2):
        k=np.cross(v1,v2)
        k=k/np.linalg.norm(k)
        theta=np.arccos(np.dot(v1,v2)/(np.linalg.norm(v1)*np.linalg.norm(v2)))
        r=scipy.spatial.transform.Rotation.from_rotvec((theta*np.array(k)))
        p=scipy.spatial.transform.Rotation.from_rotvec((np.pi*np.array([0,1,0])))
        r=r*p
        return r
    
    def get_IK(self,point,orientation_vector,seed_state=None):
        
        if seed_state==None:
            seed_state=[0,-np.pi/2,np.pi/2,-np.pi/2,-np.pi/2,0]
        x=point[0]/100+0.25
        y=point[1]/100+0.30
        z=point[2]/100
        r=self.get_rotation_from_vectors(self.aligned_tool0_vector,orientation_vector)
        quat=r.as_quat()

        sol = (self.IK_SOLVER.get_ik(seed_state,
                                x, y, z,
                                quat[0], quat[1], quat[2], quat[3])
                                )
        
        if not(sol==None):
            angles=list(sol)
        else:
            angles=None

        return angles
    
    def send_joint_path_to_moveit(self,Angles):
        time_step=0.005
        points=[]

        Joint_Point=trajectory_msgs.msg.JointTrajectoryPoint()
        Joint_Point.positions=self.move_group.get_current_joint_values()
        Joint_Point.time_from_start=rospy.Duration(0)
        Joint_Point.velocities=[0]*6
        
        time_start=rospy.Time.now()
        points.append(Joint_Point)

        for n in range(len(Angles)):
            Joint_Point=trajectory_msgs.msg.JointTrajectoryPoint()
            Joint_Point.positions=Angles[n]
            
            if n==len(Angles)-1:
                velocity=[0]*6
            else:
                velocity_last=np.array(points[n].velocities)
                velocity_next=np.array(Angles[n+1])-np.array(Angles[n])/time_step
                velocity=(velocity_last+velocity_next)/2
            
            Joint_Point.velocities=velocity
            Joint_Point.time_from_start=rospy.Duration(n*time_step)
            points.append(Joint_Point)
            
            if n==0:
                points[n+1].accelerations=velocity/time_step

            if n>1:
                acceleration_last=(np.array(points[n].velocities)-np.array(points[n-1].velocities))/time_step
                acceleration_next=(np.array(points[n+1].velocities)-np.array(points[n].velocities))/time_step
                acceleration=acceleration_last+acceleration_next/2
                points[n].accelerations=list(acceleration)

        points[-1].accelerations=[0]*6

        rtj=trajectory_msgs.msg.JointTrajectory()
        rtj.points=points
        header=std_msgs.msg.Header()
        header.frame_id="world"
        header.seq=int(1)

        header.stamp.secs=rospy.Time.now().secs
        header.stamp.nsecs=rospy.Time.now().nsecs
        rtj.header=header
        rtj.joint_names=JOINT_NAMES
        path=RobotTrajectory(joint_trajectory=rtj)

        self.move_group.execute(path,wait=True)



        
        
    
    

    


