#!/usr/bin/env python


import rospy
from numpy.random import random
import time
import tf.transformations
from tf.transformations import quaternion_from_euler
import core
from core import *
import scipy
import numpy as np
import grid_class
from grid_class import Weld_Mesh
from grid_class import TCP_solution
import matplotlib as mpl
import matplotlib.pyplot as plt
from trac_ik_python.trac_ik import IK
import moveit_commander
import geometry_msgs.msg as geometry_msgs
import sys
import moveit_msgs.msg
from std_msgs.msg import String
from moveit_commander.conversions import pose_to_list
from copy import deepcopy





def get_rotation_from_vectors(v1,v2):
    k=np.cross(v1,v2)
    k=k/np.linalg.norm(k)
    theta=np.arccos(np.dot(v1,v2)/(np.linalg.norm(v1)*np.linalg.norm(v2)))
    # print(theta)
    r=scipy.spatial.transform.Rotation.from_rotvec((theta*np.array(k)))
    p=scipy.spatial.transform.Rotation.from_rotvec((np.pi*np.array([0,1,0])))
    r=p*r
    return r





if __name__ == "__main__":
    total_joint_trajectory=[]
    jacobians_det_moveit=[]


    # Get your URDF from somewhere
    # urdf_str = 'src/ur10e_with_weld_tool/urdf/ur10e_with_weld_tool.xacro'

    moveit_commander.roscpp_initialize(sys.argv)
    rospy.init_node('move_group_python_interface_tutorial',
                anonymous=True)
    # robot = moveit_commander.RobotCommander()
    # scene = moveit_commander.PlanningSceneInterface()



    WeldMesh=Weld_Mesh(10.0,5.0,7.0,10.0,5.0,7.0,1.0,1.0,5.0)
    Solution=TCP_solution(WeldMesh)
    # Solution.get_higher_resolution_tour()
    
    
    aligned_tool0_vector=np.array([0,1,0])
    
    group_name = "manipulator"
    move_group = moveit_commander.MoveGroupCommander(group_name)
    # display_trajectory_publisher = rospy.Publisher('/move_group/display_planned_path',moveit_msgs.msg.DisplayTrajectory,queue_size=20)
    move_group.set_max_velocity_scaling_factor(1)
    move_group.set_max_acceleration_scaling_factor(1)
    move_group.clear_max_cartesian_link_speed()
    # move_group.go(wait=True)
    move_group.stop()
    move_group.clear_pose_targets()

    # pose_goal1.orientation=home.orientation
    # planning_frame = move_group.get_planning_frame()
    # print('PLANNING FRAME:')
    # print(planning_frame)


    edge=Solution.Graph.edges[Solution.tour_edges[0]]['edge']
    edge.make_orientation_vectors()

    if not(edge.PathDirection[0]==Solution.node_dict[Solution.tour_edges[0][0]]):
            edge.Path.reverse()
            edge.orientation_vectors.reverse()


    r=get_rotation_from_vectors(aligned_tool0_vector,edge.orientation_vectors[0])
    quat=r.as_quat()

    wpose=geometry_msgs.Pose()
    wpose.orientation.x=quat[0]
    wpose.orientation.y=quat[1]
    wpose.orientation.z=quat[2]
    wpose.orientation.w=quat[3]
    # print(np.array(edge.Path[k]))
    wpose.position.x=(np.array(edge.Path[0])[0]/100)+0.25
    wpose.position.y=(np.array(edge.Path[0])[1]/100)+0.25
    wpose.position.z=np.array(edge.Path[0])[2]/100
    
    waypoints=[move_group.get_current_pose().pose,wpose]


    (plan, fraction) = move_group.compute_cartesian_path(
                                   deepcopy(waypoints),   # waypoints to follow
                                   0.01,        # eef_step
                                   0.0)         # jump_threshold
    
    # for n in range(len(plan.joint_trajectory.points)):
    #     total_joint_trajectory.append(plan.joint_trajectory.points[n].positions)
    
    

    move_group.execute(plan)


    move_group.stop()
    move_group.clear_pose_targets()
    move_group.stop()

    # input("Press enter to advance")


   


    # for n in range(len(Solution.tour_edges)):

    #     current_pose = move_group.get_current_pose().pose
    #     # pose=move_group.get_current_pose().pose
        
            
    #     edge=Solution.Graph.edges[Solution.tour_edges[n]]['edge']
    #     edge.make_smooth_line(Smoothness_Coefficient=100,Interpolation_Resolution=20,Weight_Ratio=None)
    #     edge.make_orientation_vectors()
    #     if not(edge.PathDirection[0]==Solution.node_dict[Solution.tour_edges[n][0]]):
    #         edge.Path.reverse()
    #         edge.orientation_vectors.reverse()
        
    #     waypoints=[]

            
    #     for k in range(len(edge.orientation_vectors)):
    #         r=get_rotation_from_vectors(aligned_tool0_vector,edge.orientation_vectors[k])
    #         quat=r.as_quat()
    #         wpose=geometry_msgs.Pose()
    #         wpose.orientation.x=quat[0]
    #         wpose.orientation.y=quat[1]
    #         wpose.orientation.z=quat[2]
    #         wpose.orientation.w=quat[3]
    #         # print(np.array(edge.Path[k]))
    #         wpose.position.x=(np.array(edge.Path[k])[0]/100)+0.25
    #         wpose.position.y=(np.array(edge.Path[k])[1]/100)+0.25
    #         wpose.position.z=np.array(edge.Path[k])[2]/100
    #         waypoints.append(deepcopy(wpose))
        
        
    #     # print('WAYPOINTS!')
    #     # print(n)
    #     # print(waypoints)

    #     (plan, fraction) = move_group.compute_cartesian_path(
    #                                waypoints,   # waypoints to follow
    #                                0.01,        # eef_step
    #                                0.0)         # jump_threshold
        
    #     for n in range(len(plan.joint_trajectory.points)):
            
    #         joint_angles=list(plan.joint_trajectory.points[n].positions)


    #         for k in range(len(joint_angles)):
    #             if joint_angles[k]<0:
    #                 joint_angles[k]=np.pi*2-abs(joint_angles[k])
            
    #         total_joint_trajectory.append(joint_angles)
    #         jac1=np.array(move_group.get_jacobian_matrix(joint_angles))
    #         jacobians_det_moveit.append(np.linalg.det(jac1))

            
    #     # print(plan.joint_trajectory.points[0].positions)
        
    #     move_group.execute(plan,wait=True)

    #     move_group.stop()
    #     move_group.clear_pose_targets()
    #     move_group.stop()

    #     # input("Press enter to advance")

    #     # orientation_vectors=orientation_vectors+edge.orientation_vectors
    
    # total_joint_trajectory=np.array(total_joint_trajectory)

            

    
        
    







    # #GET SOLUTION FROM IK SOLVER AND PLOT:


    ik_solver = IK("base_link",
                "tool0",solve_type="Speed")
    
    # # moveit_commander.roscpp_initialize(sys.argv)
    # group_name = "manipulator"
    # move_group = moveit_commander.MoveGroupCommander(group_name)
    
    # # rospy.Time()
    
    # # ik_solver = IK('base_link', 'tool0',
    # #              timeout=0.005, epsilon=1e-5, solve_type="Speed")
    
    Solution.get_higher_resolution_tour()
    # aligned_tool0_vector=np.array([0,0,1])
    seed_state=[0.0]*ik_solver.number_of_joints
    joint_angles_ik=[]
    jacobians_det_ik=[]



    for n in range(len(Solution.tcp_points)):
        
        x=(Solution.tcp_points[n,0]/100)+0.25
        y=(Solution.tcp_points[n,1]/100)+0.25
        z=(Solution.tcp_points[n,2]/100)

        r=get_rotation_from_vectors(aligned_tool0_vector,Solution.tcp_vectors[n])
        quat=r.as_quat()
        # print([x,y,z,quat])
        sol = (ik_solver.get_ik(seed_state,
                                x, y, z,
                                quat[0], quat[1], quat[2], quat[3])
                                )
        
        angles=(list(sol))
        
        # for k in range(len(angles)):
        #     if angles[k]<0:
        #         angles[k]=np.pi*2-abs(angles[k])
        
        if not(sol==None):
            joint_angles_ik.append(angles)
            jac=np.array(move_group.get_jacobian_matrix(angles))
            jacobians_det_ik.append(np.linalg.det(jac))
        else:
            joint_angles_ik.append([-1]*ik_solver.number_of_joints)
            jacobians_det_ik.append(0)
        # print(np.linalg.det(jac))
        

        if not(sol==None):
            seed_state=sol
        else:
            seed_state=[0.0]*ik_solver.number_of_joints
    
    joint_angles_ik=np.array(joint_angles_ik)
    
    t1=np.linspace(0,1,len(joint_angles_ik))
    t2=np.linspace(0,1,len(total_joint_trajectory))

    fig, axs = plt.subplots(7,2)
    fig.suptitle('Joint Angle Solutions')
    # Defining custom 'xlim' and 'ylim' values.






    for n in range(len(joint_angles_ik)-1):
        angles_start=joint_angles_ik[n]
        angles_step=joint_angles_ik[n+1]
        delta_angles=angles_start-angles_step
        for k in range(len(delta_angles)):
            if abs(delta_angles[k])>np.pi:
                joint_angles_ik[n+1,k]=angles_start[k]+(2*np.pi-abs(delta_angles[k]))*np.sign(-(delta_angles[k]))

    # for n in range(len(joint_angles_ik[0])):
    #     max=np.max(joint_angles_ik[:,n])
    #     min=np.min(joint_angles_ik[:,n])
    #     print(max*180/np.pi)
    #     print(min*180/np.pi)
    #     if min<-2*np.pi and max>2*np.pi:
    #         print('Impossible Trajectory for Joint:')
    #         print(n)
    #     elif max>2*np.pi:
    #         joint_angles_ik[:,n]=joint_angles_ik[:,n]-(max-2*np.pi)
    #     elif min<-2*np.pi:
    #         joint_angles_ik[:,n]=joint_angles_ik[:,n]+abs(abs(min)-2*np.pi)

        





    # custom_ylim = (-360, 360)

    # Setting the values for all axes.
    # plt.setp(axs,ylim=custom_ylim)

    axs[0,0].scatter(t1,joint_angles_ik[:,0]*180/np.pi)
    axs[0,0].set_title('Q0_ik')

    axs[1,0].scatter(t1,joint_angles_ik[:,1]*180/np.pi)
    axs[1,0].set_title('Q1_ik')

    axs[2,0].scatter(t1,joint_angles_ik[:,2]*180/np.pi)
    axs[2,0].set_title('Q2_ik')

    axs[3,0].scatter(t1,joint_angles_ik[:,3]*180/np.pi)
    axs[3,0].set_title('Q3_ik')

    axs[4,0].scatter(t1,joint_angles_ik[:,4]*180/np.pi)
    axs[4,0].set_title('Q4_ik')

    axs[5,0].scatter(t1,(joint_angles_ik[:,5]*180/np.pi))
    axs[5,0].set_title('Q5_ik')

    axs[6,0].scatter(t1,jacobians_det_ik)
    axs[6,0].set_title('jacobians_det_ik')
    axs[6,0].set_ylim([-1, 1])

    # axs[0,1].scatter(t2,total_joint_trajectory[:,0]*180/np.pi)
    # axs[0,1].set_title('Q0_mi')

    # axs[1,1].scatter(t2,total_joint_trajectory[:,1]*180/np.pi)
    # axs[1,1].set_title('Q1_mi')

    # axs[2,1].scatter(t2,total_joint_trajectory[:,2]*180/np.pi)
    # axs[2,1].set_title('Q2_mi')

    # axs[3,1].scatter(t2,total_joint_trajectory[:,3]*180/np.pi)
    # axs[3,1].set_title('Q3_mi')

    # axs[4,1].scatter(t2,total_joint_trajectory[:,4]*180/np.pi)
    # axs[4,1].set_title('Q4_mi')

    # axs[5,1].scatter(t2,total_joint_trajectory[:,5]*180/np.pi)
    # axs[5,1].set_title('Q5_mi')

    # axs[6,1].scatter(t2,jacobians_det_moveit)
    # axs[6,1].set_title('jacobians_det_moveit')
    # axs[6,1].set_ylim([-1, 1])

    plt.show()

    for n in range(len(t1)):
        move_group.go(joint_angles_ik[n], wait=True)
        move_group.stop()





    # #END