#!/usr/bin/env python


import rospy
from numpy.random import random
import time
import tf.transformations
from tf.transformations import quaternion_from_euler
import core
from core import *
import scipy
import numpy as np
import grid_class_v3
from grid_class_v3 import Weld_Mesh
from grid_class_v3 import TSP_solution
import matplotlib as mpl
import matplotlib.pyplot as plt
from trac_ik_python.trac_ik import IK
import moveit_commander
import geometry_msgs.msg as geometry_msgs
import sys
import moveit_msgs.msg
from moveit_msgs.msg import RobotTrajectory
from std_msgs.msg import String
from moveit_commander.conversions import pose_to_list
from copy import deepcopy
import trajectory_msgs.msg

import actionlib
from control_msgs.msg import FollowJointTrajectoryAction, FollowJointTrajectoryGoal
from trajectory_msgs.msg import JointTrajectoryPoint

def get_rotation_from_vectors(v1,v2):
    k=np.cross(v1,v2)
    k=k/np.linalg.norm(k)
    theta=np.arccos(np.dot(v1,v2)/(np.linalg.norm(v1)*np.linalg.norm(v2)))
    # print(theta)
    r=scipy.spatial.transform.Rotation.from_rotvec((theta*np.array(k)))
    p=scipy.spatial.transform.Rotation.from_rotvec((np.pi*np.array([0,1,0])))
    r=p*r
    return r

if __name__ == "__main__":

    WeldMesh=Weld_Mesh(10.0,5.0,7.0,10.0,5.0,7.0,1.0,1.0,5.0)

    Solution=TSP_solution(WeldMesh,Include_Joint_Metrics=True)
    t1=np.linspace(0,1,len(Solution.point_angles))
    fig, axs = plt.subplots(6)
    fig.suptitle('Joint Angle Solutions for each point')

    axs[0].scatter(t1,Solution.point_angles[:,0]*180/np.pi)
    axs[0].set_title('Q0_ik')

    axs[1].scatter(t1,Solution.point_angles[:,1]*180/np.pi)
    axs[1].set_title('Q1_ik')

    axs[2].scatter(t1,Solution.point_angles[:,2]*180/np.pi)
    axs[2].set_title('Q2_ik')

    axs[3].scatter(t1,Solution.point_angles[:,3]*180/np.pi)
    axs[3].set_title('Q3_ik')

    axs[4].scatter(t1,Solution.point_angles[:,4]*180/np.pi)
    axs[4].set_title('Q4_ik')

    axs[5].scatter(t1,Solution.point_angles[:,5]*180/np.pi)
    axs[5].set_title('Q5_ikpp')
    
    plt.show()

    Solution.get_higher_resolution_tour(plot=False)

    aligned_tool0_vector=np.array([0,1,0])
    t1=np.linspace(0,1,len(Solution.TSP_angles))

    fig, axs = plt.subplots(6,2)
    fig.suptitle('Joint Angle Solutions')

    axs[0,0].scatter(t1,Solution.TSP_angles[:,0]*180/np.pi)
    axs[0,0].set_title('Q0_ik')

    axs[1,0].scatter(t1,Solution.TSP_angles[:,1]*180/np.pi)
    axs[1,0].set_title('Q1_ik')

    axs[2,0].scatter(t1,Solution.TSP_angles[:,2]*180/np.pi)
    axs[2,0].set_title('Q2_ik')

    axs[3,0].scatter(t1,Solution.TSP_angles[:,3]*180/np.pi)
    axs[3,0].set_title('Q3_ik')

    axs[4,0].scatter(t1,Solution.TSP_angles[:,4]*180/np.pi)
    axs[4,0].set_title('Q4_ik')

    axs[5,0].scatter(t1,Solution.TSP_angles[:,5]*180/np.pi)
    axs[5,0].set_title('Q5_ikpp')

    Solution.Post_proccess_path_angles()

    axs[0,1].scatter(t1,Solution.TSP_angles[:,0]*180/np.pi)
    axs[0,1].set_title('Q0_ikpp')

    axs[1,1].scatter(t1,Solution.TSP_angles[:,1]*180/np.pi)
    axs[1,1].set_title('Q1_ikpp')

    axs[2,1].scatter(t1,Solution.TSP_angles[:,2]*180/np.pi)
    axs[2,1].set_title('Q2_ikpp')

    axs[3,1].scatter(t1,Solution.TSP_angles[:,3]*180/np.pi)
    axs[3,1].set_title('Q3_ikpp')

    axs[4,1].scatter(t1,Solution.TSP_angles[:,4]*180/np.pi)
    axs[4,1].set_title('Q4_ikpp')

    axs[5,1].scatter(t1,Solution.TSP_angles[:,5]*180/np.pi)
    axs[5,1].set_title('Q5_ikpp')

    plt.show()

    Solution.Send_to_robot()




