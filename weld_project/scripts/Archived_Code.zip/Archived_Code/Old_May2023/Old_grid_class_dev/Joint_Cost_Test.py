#!/usr/bin/env python


import rospy
from numpy.random import random
import time
import tf.transformations
from tf.transformations import quaternion_from_euler
import core
from core import *
import scipy
import numpy as np
import grid_class
from grid_class import Weld_Mesh
from grid_class import TCP_solution
import matplotlib as mpl
import matplotlib.pyplot as plt
from trac_ik_python.trac_ik import IK
import moveit_commander
import geometry_msgs.msg as geometry_msgs
import sys
import moveit_msgs.msg
from std_msgs.msg import String
from moveit_commander.conversions import pose_to_list
from copy import deepcopy



def get_rotation_from_vectors(v1,v2):
    k=np.cross(v1,v2)
    k=k/np.linalg.norm(k)
    theta=np.arccos(np.dot(v1,v2)/(np.linalg.norm(v1)*np.linalg.norm(v2)))
    # print(theta)
    r=scipy.spatial.transform.Rotation.from_rotvec((theta*np.array(k)))
    p=scipy.spatial.transform.Rotation.from_rotvec((np.pi*np.array([0,1,0])))
    r=p*r
    return r






if __name__ == "__main__":
    WeldMesh=Weld_Mesh(10.0,5.0,7.0,10.0,5.0,7.0,1.0,1.0,5.0)
    Solution=TCP_solution(WeldMesh,Include_Joint_Metrics=True)
    Solution.get_higher_resolution_tour(plot=False)

    aligned_tool0_vector=np.array([0,1,0])
    t1=np.linspace(0,1,len(Solution.tcp_angles))
    # print(Solution.tcp_angles)

    fig, axs = plt.subplots(6,2)
    fig.suptitle('Joint Angle Solutions')

    # custom_ylim = (-360, 360)

    # Setting the values for all axes.
    # plt.setp(axs,ylim=custom_ylim)

    axs[0,0].scatter(t1,Solution.tcp_angles[:,0]*180/np.pi)
    axs[0,0].set_title('Q0_ik')

    axs[1,0].scatter(t1,Solution.tcp_angles[:,1]*180/np.pi)
    axs[1,0].set_title('Q1_ik')

    axs[2,0].scatter(t1,Solution.tcp_angles[:,2]*180/np.pi)
    axs[2,0].set_title('Q2_ik')

    axs[3,0].scatter(t1,Solution.tcp_angles[:,3]*180/np.pi)
    axs[3,0].set_title('Q3_ik')

    axs[4,0].scatter(t1,Solution.tcp_angles[:,4]*180/np.pi)
    axs[4,0].set_title('Q4_ik')

    axs[5,0].scatter(t1,Solution.tcp_angles[:,5]*180/np.pi)
    axs[5,0].set_title('Q5_ikpp')

    # Solution.Post_proccess_path_angles()

    axs[0,1].scatter(t1,Solution.tcp_angles[:,0]*180/np.pi)
    axs[0,1].set_title('Q0_ikpp')

    axs[1,1].scatter(t1,Solution.tcp_angles[:,1]*180/np.pi)
    axs[1,1].set_title('Q1_ikpp')

    axs[2,1].scatter(t1,Solution.tcp_angles[:,2]*180/np.pi)
    axs[2,1].set_title('Q2_ikpp')

    axs[3,1].scatter(t1,Solution.tcp_angles[:,3]*180/np.pi)
    axs[3,1].set_title('Q3_ikpp')

    axs[4,1].scatter(t1,Solution.tcp_angles[:,4]*180/np.pi)
    axs[4,1].set_title('Q4_ikpp')

    axs[5,1].scatter(t1,Solution.tcp_angles[:,5]*180/np.pi)
    axs[5,1].set_title('Q5_ikpp')

    plt.show()

    #COMPARE

    
    
    # moveit_commander.roscpp_initialize(sys.argv)
    # group_name = "manipulator"
    # move_group = moveit_commander.MoveGroupCommander(group_name)

    # ik_solver = IK("base_link",
    #             "tool0",solve_type="Speed")
    
    # # rospy.Time()
    
    # ik_solver = IK('base_link', 'tool0',
    #              timeout=0.005, epsilon=1e-5, solve_type="Speed")
    
    # Solution.get_higher_resolution_tour()
    # aligned_tool0_vector=np.array([0,0,1])
    # seed_state=[0.0]*ik_solver.number_of_joints
    # joint_angles_ik=[]
    # jacobians_det_ik=[]



    # for n in range(len(Solution.tcp_points)):
        
    #     x=(Solution.tcp_points[n,0]/100)+0.25
    #     y=(Solution.tcp_points[n,1]/100)+0.25
    #     z=(Solution.tcp_points[n,2]/100)

    #     r=get_rotation_from_vectors(aligned_tool0_vector,Solution.tcp_vectors[n])
    #     quat=r.as_quat()
    #     # print([x,y,z,quat])
    #     sol = (ik_solver.get_ik(seed_state,
    #                             x, y, z,
    #                             quat[0], quat[1], quat[2], quat[3])
    #                             )
        
    #     angles=(sol)
        
    #     # for k in range(len(angles)):
    #     #     if angles[k]<0:
    #     #         angles[k]=np.pi*2-abs(angles[k])
        
    #     if not(sol==None):
    #         joint_angles_ik.append(angles)
    #         jac=np.array(move_group.get_jacobian_matrix(angles))
    #         jacobians_det_ik.append(np.linalg.det(jac))
    #     else:
    #         joint_angles_ik.append([-1]*ik_solver.number_of_joints)
    #         jacobians_det_ik.append(0)
    #     # print(np.linalg.det(jac))
        

    #     if not(sol==None):
    #         seed_state=sol
    #     else:
    #         seed_state=[0.0]*ik_solver.number_of_joints

    # joint_angles_ik=np.array(joint_angles_ik)
    
    # for n in range(len(joint_angles_ik)-1):
    #     angles_start=joint_angles_ik[n]
    #     angles_step=joint_angles_ik[n+1]
    #     delta_angles=np.array(angles_start)-np.array(angles_step)
    #     for k in range(len(delta_angles)):
    #         if abs(delta_angles[k])>np.pi:
    #             joint_angles_ik[n+1,k]=angles_start[k]+(2*np.pi-abs(delta_angles[k]))*np.sign(-(delta_angles[k]))


    
    
    # t1=np.linspace(0,1,len(joint_angles_ik))

    # fig, axs = plt.subplots(7)
    # fig.suptitle('Joint Angle Solutions')
    # # Defining custom 'xlim' and 'ylim' values.

    # axs[0].scatter(t1,joint_angles_ik[:,0]*180/np.pi)
    # axs[0].set_title('Q0_ik')

    # axs[1].scatter(t1,joint_angles_ik[:,1]*180/np.pi)
    # axs[1].set_title('Q1_ik')

    # axs[2].scatter(t1,joint_angles_ik[:,2]*180/np.pi)
    # axs[2].set_title('Q2_ik')

    # axs[3].scatter(t1,joint_angles_ik[:,3]*180/np.pi)
    # axs[3].set_title('Q3_ik')

    # axs[4].scatter(t1,joint_angles_ik[:,4]*180/np.pi)
    # axs[4].set_title('Q4_ik')

    # axs[5].scatter(t1,(joint_angles_ik[:,5]*180/np.pi))
    # axs[5].set_title('Q5_ik')

    # axs[6].scatter(t1,jacobians_det_ik)
    # axs[6].set_title('jacobians_det_ik')
    # axs[6].set_ylim([-1, 1])
    
    # plt.show()



    #END