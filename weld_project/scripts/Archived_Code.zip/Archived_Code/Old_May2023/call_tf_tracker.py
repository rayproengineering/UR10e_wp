#!/usr/bin/env python


import sys
import move_module
import rospy
from std_msgs.msg import String
import std_msgs
import tf2_msgs
import geometry_msgs.msg



def callback(data):
    rospy.loginfo(data)
    

def test_node_1():
    rospy.init_node('test_node_1', anonymous=True)
    rospy.Subscriber("Tool_Orientation", geometry_msgs.msg.Transform, callback)
    

    rospy.spin()
    


if __name__ == "__main__":

    
    test_node_1()
    
    
    






    # # tracker1=tf_monitor('tool0_controller', 'base')
    # print(rostopic.get_info_text('/tf'))

    # print('HI')