#!/usr/bin/env python
import rospy
import sys
import tf2_ros
import geometry_msgs.msg as geometry_msgs
import numpy as np
import test
import move_module
from move_module import *
import rosbag

if __name__ == "__main__":
    bag = rosbag.Bag('test.bag','r',True)
    msg= bag.read_messages(topics='points_des')
    print(msg)
    bag.close()

    
    
    

        



