import sys
import copy
import rospy
import moveit_commander
import moveit_msgs.msg
from moveit_msgs.msg import RobotState
import geometry_msgs.msg as geometry_msgs
from math import pi
from std_msgs.msg import String
from moveit_commander.conversions import pose_to_list
import numpy as np
import quad_class
from quad_class import *
import random





def calculate_average_points(points_array):
    x_avg=0
    y_avg=0
    z_avg=0
    
    for n in range(len(points_array)):
        x_avg+=points_array[n][0]
        y_avg+=points_array[n][1]
        z_avg+=points_array[n][2]
    x_avg=x_avg/len(points_array)
    y_avg=y_avg/len(points_array)
    z_avg=z_avg/len(points_array)
    return(x_avg,y_avg,z_avg)



def extract_pose_data(Pose_List,datatype):
    
    data=[]

    if datatype=='all':
        for n in range(len(Pose_List.poses)):
            data.append(((Pose_List.poses[n].position.x, Pose_List.poses[n].position.y, Pose_List.poses[n].position.z)\
                ,(Pose_List.poses[n].orientation.x, Pose_List.poses[n].orientation.y, Pose_List.poses[n].orientation.z, Pose_List.poses[n].orientation.w)))
    if datatype=='cart':
        for n in range(len(Pose_List.poses)):
            data.append((Pose_List.poses[n].position.x, Pose_List.poses[n].position.y, Pose_List.poses[n].position.z))
    if datatype=='cart_2D':
        for n in range(len(Pose_List.poses)):
            data.append((Pose_List.poses[n].position.x, Pose_List.poses[n].position.y))     
    return(data)

def order_square_traj(square_points):
    ordered_pairs=[]
    ordered_pairs.append(square_points[0][0])
    for n in range(len(square_points[0])-1):
        distance_array=[]
        for k in range(len(square_points[0])-1):
            if ordered_pairs[n]==square_points[0][k] or square_points[0][k] in ordered_pairs:
                d1=np.inf
            else:
                d1=[abs(ordered_pairs[n][0]-square_points[0][k][0]),abs(ordered_pairs[n][0]-square_points[0][k][1])]
            distance_array.append(d1)
        index=np.argmin(distance_array)+1+n
        ordered_pairs.append(square_points[0][index])
    return ordered_pairs

    
    





def callback(data):

    robot = moveit_commander.RobotCommander()
    p1=[-0.381917095449,0.0131360144927,0.0496606899817,0.0595364680115,-0.0107198093161,-0.718671882346,0.692712942127] 
    p2=[-0.621449614418,0.230997417726,0.0454614316896,0.109802754875,-0.0613185754944,0.0941112690113,0.987586176678]
    p3=[ -0.838474255372,0.00371210184772,0.0631144626098,0.0807426406273,0.125876769419,0.727729467824,0.669361999643]
    p4=[-0.614984532347,-0.218115580518,0.0807048160323,-0.0297954819048,0.237925057534,0.965565646562,0.100930067047]


    # POINT1=[0.611148601777,-0.234607308147,0.0225495672672,-0.0591323383422,0.00303318270996,0.126969835956,-0.990137781888]
    # POINT2=[0.391173715934,0.0160042793341,0.014825486191,-0.0407093592394,0.0289561309455,0.65360378993,-0.755186318957]
    # POINT3=[0.614768403499,0.217254536215,0.0193412119233,0.025301045895,-0.064455005233,-0.997391950907,-0.0203643227929]
    # POINT4=[0.839847332224,-0.00867500246281,0.0240599709825,-0.133017383595,-0.083370354542,-0.702823460786,-0.693826305796]

    POINT1=p1
    POINT2=p2
    POINT3=p3
    POINT4=p4


    Pose1=geometry_msgs.Pose(geometry_msgs.Vector3(POINT1[0], POINT1[1], POINT1[2]), \
        geometry_msgs.Quaternion(POINT1[3], POINT1[4], POINT1[5],POINT1[6]))
    Pose2=geometry_msgs.Pose(geometry_msgs.Vector3(POINT2[0], POINT2[1], POINT2[2]), \
        geometry_msgs.Quaternion(POINT2[3], POINT2[4], POINT2[5],POINT2[6]))
    Pose3=geometry_msgs.Pose(geometry_msgs.Vector3(POINT3[0], POINT3[1], POINT3[2]), \
        geometry_msgs.Quaternion(POINT3[3], POINT3[4], POINT3[5],POINT3[6]))
    Pose4=geometry_msgs.Pose(geometry_msgs.Vector3(POINT4[0], POINT4[1], POINT4[2]), \
        geometry_msgs.Quaternion(POINT4[3], POINT4[4], POINT4[5],POINT4[6]))

    # Pose_Array=data
    
    Pose_Array=geometry_msgs.PoseArray()
    Pose_Array.poses=[Pose1,Pose2,Pose3,Pose4]
    print(Pose_Array)

    cart_points=extract_pose_data(Pose_Array,'cart')
    print(cart_points)

    average_point=calculate_average_points(cart_points)
    print(average_point)

    print(extract_pose_data(Pose_Array,'cart_2D'))

    square_points=(get_squares(extract_pose_data(Pose_Array,'cart_2D')))
    print(square_points[0])

    ord=order_square_traj(square_points)
    print('HI')
    print(ord)

    pose_dict={}
    for n in range(len(Pose_Array.poses)):
        key=(Pose_Array.poses[n].position.x,Pose_Array.poses[n].position.y)
        pose_dict[key]=Pose_Array.poses[n]
    print(pose_dict)

    # group_name= 'ur10e_robot'
    group_name = "manipulator"
    move_group = moveit_commander.MoveGroupCommander(group_name)
    display_trajectory_publisher = rospy.Publisher('/move_group/display_planned_path',moveit_msgs.msg.DisplayTrajectory,queue_size=20)
    pose=move_group.get_current_pose().pose
    print('HI AGAIN')
    print(pose)

    move_group.clear_pose_targets()
    planning_frame = move_group.get_planning_frame()
    print(planning_frame)

    # joint_goal=move_group.
    # print(np.degrees(joint_goal[0]))
    joint_goal = move_group.get_current_joint_values()
    print('HI')
    print(joint_goal)
    joint_goal[0] = (np.radians(180))
    joint_goal[1] = (np.radians(-90))
    joint_goal[2] = (np.radians(90))
    joint_goal[3] = (np.radians(90))
    joint_goal[4] = (np.radians(90))
    joint_goal[5] = (np.radians(180))

    move_group.go(joint_goal, wait=True)
    move_group.stop()
    move_group.clear_pose_targets()
    move_group.stop()
    # move_group.set_planning_frame('base_link')
    pose_goal = geometry_msgs.Pose()
    pose_goal.orientation.w = 1.0
    pose_goal.position.x = average_point[0]
    pose_goal.position.y = average_point[1]
    pose_goal.position.z = average_point[2]+0.05
    waypoints = []
    current_pose = move_group.get_current_pose().pose
    x_points=np.linspace(current_pose.position.x,pose_goal.position.x,5)
    y_points=np.linspace(current_pose.position.y,pose_goal.position.y,5)
    z_points=np.linspace(current_pose.position.z,pose_goal.position.z,5)
    for n in range(len(x_points)):
        pose_goal = geometry_msgs.Pose()
        # pose_goal.orientation.w = 1
        pose_goal.position.x = x_points[n]
        pose_goal.position.y = y_points[n]
        pose_goal.position.z = z_points[n]
        waypoints.append(pose_goal)
    # print(ord)

    (plan, fraction) = move_group.compute_cartesian_path(
                                    waypoints,   # waypoints to follow
                                    0.001,        # eef_step
                                    0.0)         # jump_threshold
    move_group.execute(plan, wait=True)

    move_group.stop()
    move_group.clear_pose_targets()

    current_pose = move_group.get_current_pose().pose
    waypoints = []
    pose=move_group.get_current_pose().pose
    print('HI AGAIN')
    print(pose)
    

    


    x_points=np.linspace(current_pose.position.x,pose_dict[ord[0]].position.x,5)
    y_points=np.linspace(current_pose.position.y,pose_dict[ord[0]].position.y,5)
    z_points=np.linspace(current_pose.position.z,pose_dict[ord[0]].position.z,5)
    xw_points=np.linspace(current_pose.orientation.x,pose_dict[ord[0]].orientation.x,5)
    yw_points=np.linspace(current_pose.orientation.y,pose_dict[ord[0]].orientation.y,5)
    zw_points=np.linspace(current_pose.orientation.z,pose_dict[ord[0]].orientation.z,5)
    ww_points=np.linspace(current_pose.orientation.w,pose_dict[ord[0]].orientation.w,5)




    for n in range(len(x_points)):
        pose_goal = geometry_msgs.Pose()
        # pose_goal.orientation.w = 1
        pose_goal.position.x = x_points[n]
        pose_goal.position.y = y_points[n]
        pose_goal.position.z = z_points[n]
        pose_goal.orientation.x = xw_points[n]
        pose_goal.orientation.y = yw_points[n]
        pose_goal.orientation.z = zw_points[n]
        pose_goal.orientation.w = ww_points[n]
        waypoints.append(pose_goal)
    
    (plan, fraction) = move_group.compute_cartesian_path(
                                    waypoints,   # waypoints to follow
                                    0.001,        # eef_step
                                    0.0)         # jump_threshold

    move_group.execute(plan, wait=True)
    move_group.stop()
    move_group.clear_pose_targets()
    current_pose = move_group.get_current_pose().pose
    waypoints = []
    

    x_points=np.linspace(current_pose.position.x,pose_dict[ord[1]].position.x,5)
    y_points=np.linspace(current_pose.position.y,pose_dict[ord[1]].position.y,5)
    z_points=np.linspace(current_pose.position.z,pose_dict[ord[1]].position.z,5)
    xw_points=np.linspace(current_pose.orientation.x,pose_dict[ord[1]].orientation.x,5)
    yw_points=np.linspace(current_pose.orientation.y,pose_dict[ord[1]].orientation.y,5)
    zw_points=np.linspace(current_pose.orientation.z,pose_dict[ord[1]].orientation.z,5)
    ww_points=np.linspace(current_pose.orientation.w,pose_dict[ord[1]].orientation.w,5)
    for n in range(len(x_points)):
        pose_goal = geometry_msgs.Pose()
        # pose_goal.orientation.w = 1
        pose_goal.position.x = x_points[n]
        pose_goal.position.y = y_points[n]
        pose_goal.position.z = z_points[n]
        pose_goal.orientation.x = xw_points[n]
        pose_goal.orientation.y = yw_points[n]
        pose_goal.orientation.z = zw_points[n]
        pose_goal.orientation.w = ww_points[n]
        waypoints.append(pose_goal)

    (plan, fraction) = move_group.compute_cartesian_path(
                                    waypoints,   # waypoints to follow
                                    0.001,        # eef_step
                                    0.0)         # jump_threshold

    move_group.execute(plan, wait=True)
    # move_gro?up.wait()
    move_group.stop()
    move_group.clear_pose_targets()
    current_pose = move_group.get_current_pose().pose
    waypoints = []


    x_points=np.linspace(current_pose.position.x,pose_dict[ord[2]].position.x,5)
    y_points=np.linspace(current_pose.position.y,pose_dict[ord[2]].position.y,5)
    z_points=np.linspace(current_pose.position.z,pose_dict[ord[2]].position.z,5)
    xw_points=np.linspace(current_pose.orientation.x,pose_dict[ord[2]].orientation.x,5)
    yw_points=np.linspace(current_pose.orientation.y,pose_dict[ord[2]].orientation.y,5)
    zw_points=np.linspace(current_pose.orientation.z,pose_dict[ord[2]].orientation.z,5)
    ww_points=np.linspace(current_pose.orientation.w,pose_dict[ord[2]].orientation.w,5)
    for n in range(len(x_points)):
        pose_goal = geometry_msgs.Pose()
        # pose_goal.orientation.w = 1
        pose_goal.position.x = x_points[n]
        pose_goal.position.y = y_points[n]
        pose_goal.position.z = z_points[n]
        pose_goal.orientation.x = xw_points[n]
        pose_goal.orientation.y = yw_points[n]
        pose_goal.orientation.z = zw_points[n]
        pose_goal.orientation.w = ww_points[n]
        waypoints.append(pose_goal)

    (plan, fraction) = move_group.compute_cartesian_path(
                                    waypoints,   # waypoints to follow
                                    0.001,        # eef_step
                                    0.0)         # jump_threshold


    move_group.execute(plan, wait=True)
    move_group.stop()
    move_group.clear_pose_targets()
    current_pose = move_group.get_current_pose().pose
    waypoints = []

    # x_points=np.linspace(current_pose.position.x,pose_dict[ord[3]].position.x,5)
    # y_points=np.linspace(current_pose.position.y,pose_dict[ord[3]].position.y,5)
    # z_points=np.linspace(current_pose.position.z,pose_dict[ord[3]].position.z,5)
    # xw_points=np.linspace(current_pose.orientation.x,pose_dict[ord[3]].orientation.x,5)
    # yw_points=np.linspace(current_pose.orientation.y,pose_dict[ord[3]].orientation.y,5)
    # zw_points=np.linspace(current_pose.orientation.z,pose_dict[ord[3]].orientation.z,5)
    # ww_points=np.linspace(current_pose.orientation.w,pose_dict[ord[3]].orientation.w,5)
    # for n in range(len(x_points)):
    #     pose_goal = geometry_msgs.Pose()
    #     # pose_goal.orientation.w = 1
    #     pose_goal.position.x = x_points[n]
    #     pose_goal.position.y = y_points[n]
    #     pose_goal.position.z = z_points[n]
    #     pose_goal.orientation.x = xw_points[n]
    #     pose_goal.orientation.y = yw_points[n]
    #     pose_goal.orientation.z = zw_points[n]
    #     pose_goal.orientation.w = ww_points[n]
    #     waypoints.append(pose_goal)

    # (plan, fraction) = move_group.compute_cartesian_path(
    #                                 waypoints,   # waypoints to follow
    #                                 0.001,        # eef_step
    #                                 0.0)         # jump_threshold


    # move_group.execute(plan, wait=True)
    # move_group.stop()
    # move_group.clear_pose_targets()
    # current_pose = move_group.get_current_pose().pose
    # waypoints = []

    

    # x_points=np.linspace(current_pose.position.x,pose_dict[ord[0]].position.x,5)
    # y_points=np.linspace(current_pose.position.y,pose_dict[ord[0]].position.y,5)
    # z_points=np.linspace(current_pose.position.z,pose_dict[ord[0]].position.z,5)
    # xw_points=np.linspace(current_pose.orientation.x,pose_dict[ord[0]].orientation.x,5)
    # yw_points=np.linspace(current_pose.orientation.y,pose_dict[ord[0]].orientation.y,5)
    # zw_points=np.linspace(current_pose.orientation.z,pose_dict[ord[0]].orientation.z)
    # ww_points=np.linspace(current_pose.orientation.w,pose_dict[ord[0]].orientation.w,5)
    # for n in range(len(x_points)):
    #     pose_goal = geometry_msgs.Pose()
    #     # pose_goal.orientation.w = 1
    #     pose_goal.position.x = x_points[n]
    #     pose_goal.position.y = y_points[n]
    #     pose_goal.position.z = z_points[n]
    #     pose_goal.orientation.x = xw_points[n]
    #     pose_goal.orientation.y = yw_points[n]
    #     pose_goal.orientation.z = zw_points[n]
    #     pose_goal.orientation.w = ww_points[n]
    #     waypoints.append(pose_goal)

    # (plan, fraction) = move_group.compute_cartesian_path(
    #                                 waypoints,   # waypoints to follow
    #                                 0.001,        # eef_step
    #                                 0.0)         # jump_threshold

    # move_group.execute(plan, wait=True)
    # # move_group.wait()
    # move_group.stop()
    # move_group.clear_pose_targets()

    # waypoints = []
    current_pose = move_group.get_current_pose().pose



    pose_goal = geometry_msgs.Pose()
    # pose_goal.orientation.w = 1.0
    pose_goal.position.x = average_point[0]
    pose_goal.position.y = average_point[1]
    pose_goal.position.z = average_point[2]+0.1

    x_points=np.linspace(current_pose.position.x,pose_goal.position.x,5)
    y_points=np.linspace(current_pose.position.y,pose_goal.position.y,5)
    z_points=np.linspace(current_pose.position.z,pose_goal.position.z,5)

    for n in range(len(x_points)):
        pose_goal = geometry_msgs.Pose()
        # pose_goal.orientation.w = 1
        pose_goal.position.x = x_points[n]
        pose_goal.position.y = y_points[n]
        pose_goal.position.z = z_points[n]
        waypoints.append(pose_goal)
    
    
    
    (plan, fraction) = move_group.compute_cartesian_path(
                                    waypoints,   # waypoints to follow
                                    0.001,        # eef_step
                                    0.0)         # jump_threshold

    move_group.execute(plan, wait=True)
    move_group.stop()
    move_group.clear_pose_targets()
    

    


    








    # move_group.set_pose_target(pose_goal)

    # plan = move_group.go(wait=True)
    # Calling `stop()` ensures that there is no residual movement
    # move_group.stop()
    # It is always good to clear your targets after planning with poses.
    # Note: there is no equivalent function for clear_joint_value_targets()
    # move_group.clear_pose_targets()

    # display_trajectory = moveit_msgs.msg.DisplayTrajectory()
    # display_trajectory.trajectory_start = robot.get_current_state()
    # display_trajectory.trajectory.append(plan)
    # # Publish
    # display_trajectory_publisher.publish(display_trajectory);

    # move_group.clear_pose_targets()




    # joint_goal = move_group.get_current_joint_values()
    # joint_start=[1.4284423033343714, -1.047367886906006, 2.834364891052246, 1.0147973734089355, 1.4199786186218262, 5.930780410766602]
    # joint_start[0] = joint_start[2]
    # joint_start[1] = joint_start[1]
    # joint_start[2] = joint_start[0]
    # joint_start[3] = joint_start[3]
    # joint_start[4] = joint_start[4]
    # joint_start[5] = joint_start[5]
    # move_it_robot_start_state= RobotState()
    # move_it_robot_start_state.joint_state=joint_start
    # move_group.set_start_state=(joint_start)
    # print('hi')


    # joint_goal=[0, -1.047367886906006, 2.834364891052246, 1.0147973734089355, 1.4199786186218262, 5.930780410766602]
    # print(np.degrees(joint_goal[0]))
    # joint_goal[0] = joint_goal[2]
    # joint_goal[1] = joint_goal[1]
    # joint_goal[2] = joint_goal[0]
    # joint_goal[3] = joint_goal[3]
    # joint_goal[4] = joint_goal[4]
    # joint_goal[5] = joint_goal[5]
    # print(joint_goal)
    # # joint_goal[6] = 0

    # The go command can be called with joint values, poses, or without any
    # parameters if you have already set the pose or joint target for the group
    # move_group.go(joint_goal, wait=True)

    # Calling ``stop()`` ensures that there is no residual movement
    # move_group.stop()
    # eef_link = move_group.get_end_effector_link()
    # move_group.set_end_effector_link
    # print(eef_link)
    # # print(vars(eef_link))
    # print(move_group.get_planning_frame())
    rospy.signal_shutdown("Executed")

if __name__ == "__main__":


    moveit_commander.roscpp_initialize(sys.argv)
    rospy.init_node('move_group_python', anonymous=True)

    rospy.Subscriber('desired_points',geometry_msgs.PoseArray, callback)
    rospy.spin()


