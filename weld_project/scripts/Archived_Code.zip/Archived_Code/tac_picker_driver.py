#!/usr/bin/env python3

import pyvista as pv
import numpy as np
import scipy
from copy import deepcopy
import Weld_Select
from Weld_Select import *

# Weld_Mesh=pv.Weld_Mesh()
Weld_Part_Mesh_File_Name='Weld_Mesh_V1.stl'
Weld_Mesh=pv.read(Weld_Part_Mesh_File_Name)
r=scipy.spatial.transform.Rotation.random()
vector=np.random.rand(1,3)
perturbed_points=[]
perturbed_points_true=[]

for n in range(len(Weld_Mesh.points)):
    point=deepcopy(Weld_Mesh.points[n])
    point=np.array(r.apply(deepcopy(Weld_Mesh.points[n])))+vector*10+(np.random.rand(1,3)/10)
    point_true=np.array(r.apply(deepcopy(Weld_Mesh.points[n])))+vector*10
    perturbed_points.append(list(point)[0])
    perturbed_points_true.append(list(point_true)[0])

B=np.array(perturbed_points)
Welds=Create_Welds(Weld_Part_Mesh_File_Name)







